# loadtest/fake_images.py
#
# Generates tiny, genuinely-valid PNG images with no external
# dependencies (no Pillow - matching the 128MB build's own choice not
# to install it). Each call can produce a distinct solid color so the
# real pipeline's SHA-256 exact-duplicate cache (gemini_queue._hash_image)
# sees distinct images by default, with an optional duplicate rate to
# deliberately exercise that cache path.
#
# Used in BOTH modes:
#   - mock mode: content is irrelevant (the mock transport never looks
#     at the bytes), but realistic byte sizes matter for realistic
#     queue memory behavior.
#   - real mode: this image is genuinely sent to Gemini. A tiny solid-
#     color image reliably comes back as a legitimate "no food
#     detected" result - a real, valid outcome that exercises the full
#     pipeline (HTTP call, JSON parsing, finalization, queue bookkeeping)
#     for the lowest plausible token cost, instead of spending real
#     quota on genuine food-photo analysis just to load-test plumbing.

from __future__ import annotations

import random
import struct
import zlib


def _png_chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def make_solid_png(width: int, height: int, rgb: tuple[int, int, int]) -> bytes:
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8-bit RGB, no interlace
    row = bytes([0]) + bytes(rgb) * width  # filter type 0 (none) + pixels
    raw = row * height
    idat = zlib.compress(raw, level=6)
    return sig + _png_chunk(b"IHDR", ihdr) + _png_chunk(b"IDAT", idat) + _png_chunk(b"IEND", b"")


class ImageProvider:
    """Produces (image_bytes, media_type) pairs for load-test jobs.

    duplicate_rate: probability [0,1] that a job reuses a previously
    generated image instead of a fresh one, to exercise the real
    dedup/caching path in gemini_queue.py on demand. 0.0 (default)
    means every job gets a distinct image.
    """

    def __init__(self, size_px: int = 16, duplicate_rate: float = 0.0, seed: int | None = None):
        self.size_px = size_px
        self.duplicate_rate = duplicate_rate
        self.rng = random.Random(seed)
        self._pool: list[bytes] = []

    def next_image(self) -> tuple[bytes, str]:
        if self._pool and self.rng.random() < self.duplicate_rate:
            return self.rng.choice(self._pool), "image/png"
        rgb = (self.rng.randrange(256), self.rng.randrange(256), self.rng.randrange(256))
        img = make_solid_png(self.size_px, self.size_px, rgb)
        self._pool.append(img)
        return img, "image/png"
