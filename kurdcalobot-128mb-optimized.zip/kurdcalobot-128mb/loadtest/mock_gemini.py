# loadtest/mock_gemini.py
#
# Replaces vision._gemini_rest_request - the ONE function in the whole
# codebase that actually makes an HTTP call to Gemini (see vision.py's
# own comment above that function) - with a fake that never touches the
# network. Everything else is real and untouched:
#
#   - vision.estimate_calories / estimate_calories_batch: real retry
#     loop, real backoff, real 429-specific retry budget, real JSON
#     parsing/finalization.
#   - gemini_queue.py: real per-model queues/workers, real batching,
#     real adaptive pacing (AIMD), real daily-budget pacing, real
#     circuit breaker, real per-user cooldown/rapid-fire escalation,
#     real duplicate-image caching.
#
# The mock mimics the REAL function's contract exactly:
#   - increments the same vision._http_stats counters the real function
#     increments (so gemini_queue.get_stats_summary()'s http-layer
#     numbers stay meaningful in mock mode too - nothing double-counts,
#     nothing goes uncounted).
#   - raises the same exception types (vision.GeminiAPIError for HTTP
#     error codes, ConnectionError for network-layer failures) so the
#     real _classify_and_log / retry logic in vision.py branches exactly
#     as it would against real Gemini.
#   - blocks the calling thread for a simulated latency, because the
#     real function is synchronous and is always invoked via
#     asyncio.to_thread(...) from gemini_queue.py - matching that shape
#     matters for realistic concurrency behavior in the test.
#
# This module is only ever installed for the lifetime of a single load
# test run, and only against the `vision` module object in THIS process
# (the load tester's own process, never the production bot's process).

from __future__ import annotations

import dataclasses
import json
import random
import time

import vision as _vision


@dataclasses.dataclass
class MockGeminiConfig:
    """Tunable knobs for the fake Gemini backend.

    error_rate: overall probability a given real HTTP attempt fails.
    Split three ways among the failure shares below (must sum to 1.0):
      - rate_limit_share -> HTTP 429 (retryable, its own short retry
        budget in vision.py)
      - server_error_share -> HTTP 503 (retryable, generic backoff)
      - hard_error_share -> HTTP 400 (NOT retryable - simulates a bad
        request slipping through, e.g. bad payload/key)
    latency_mean/jitter: simulated per-HTTP-attempt latency in seconds
      (gaussian, floored at 0). Keep small - this models Gemini's real
      response time, not network chaos; use error_rate for chaos.
    no_food_rate: fraction of successful responses that come back as a
      genuine "no food in this photo" result (a real, valid outcome
      path, not a failure).
    seed: set for reproducible test runs; None for real randomness.
    """

    error_rate: float = 0.05
    rate_limit_share: float = 0.6
    server_error_share: float = 0.3
    hard_error_share: float = 0.1
    latency_mean: float = 0.6
    latency_jitter: float = 0.35
    no_food_rate: float = 0.03
    seed: int | None = None

    def __post_init__(self):
        total = self.rate_limit_share + self.server_error_share + self.hard_error_share
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"failure-mode shares must sum to 1.0, got {total}")


_SAMPLE_FOOD_NAMES = [
    ("برنج و گۆشت", "🍚"), ("دۆڵمە", "🥬"), ("کەباب", "🍢"),
    ("نان و پەنیر", "🧀"), ("سالادی جێرگ", "🥗"), ("قەیمە", "🍲"),
    ("تەپسی", "🍛"), ("کوفتە", "🍡"),
]


def _fake_single_result(rng: random.Random, no_food_rate: float) -> dict:
    if rng.random() < no_food_rate:
        return {"no_food_detected": True, "foods": []}
    n_items = rng.randint(1, 3)
    foods = []
    for _ in range(n_items):
        name, emoji = rng.choice(_SAMPLE_FOOD_NAMES)
        kcal = rng.randint(120, 650)
        foods.append({
            "name_kurdish": name,
            "emoji": emoji,
            "portion_kurdish": "یەک پارچە",
            "kcal": kcal,
            "protein_g": round(kcal * 0.12 / 4, 1),
            "carbs_g": round(kcal * 0.5 / 4, 1),
            "fat_g": round(kcal * 0.3 / 9, 1),
            "matched_glossary": False,
        })
    return {
        "foods": foods,
        "confidence": rng.choice(["بەرز", "مامناوەند"]),
        "note_kurdish": "",
        "insight_kurdish": "🔥 (mock) خواردنێکی وزەبەخشە.",
        "alternatives": [],
    }


def _count_images_in_payload(payload: dict) -> int:
    try:
        parts = payload["contents"][0]["parts"]
    except (KeyError, IndexError, TypeError):
        return 1
    return sum(1 for p in parts if isinstance(p, dict) and "inline_data" in p)


def _raise_for_roll(rng: random.Random, config: MockGeminiConfig):
    """Picks a failure mode and updates vision._http_stats exactly like
    the real _gemini_rest_request does on each corresponding path."""
    outcome = rng.random()
    if outcome < config.rate_limit_share:
        _vision._http_stats["raw_http_429_responses"] += 1
        # Mirrors the real "retry in Ns" phrasing that
        # vision._extract_retry_after_seconds looks for, so the real
        # retry-after parsing path gets exercised too.
        retry_after = rng.choice([5, 12, 20, 45, 90])
        raise _vision.GeminiAPIError(429, f"Mock quota: Please retry in {retry_after}.0s.")
    elif outcome < config.rate_limit_share + config.server_error_share:
        _vision._http_stats["raw_http_other_failures"] += 1
        raise _vision.GeminiAPIError(503, "Mock: model overloaded, try again")
    else:
        _vision._http_stats["raw_http_other_failures"] += 1
        raise _vision.GeminiAPIError(400, "Mock: malformed request (non-retryable)")


def _make_fake_transport(config: MockGeminiConfig):
    rng = random.Random(config.seed)

    def fake_gemini_rest_request(model: str, payload: dict, timeout: float = 45.0) -> str:
        _vision._http_stats["raw_http_attempts"] += 1

        latency = max(0.0, rng.gauss(config.latency_mean, config.latency_jitter))
        time.sleep(latency)

        if rng.random() < config.error_rate:
            _raise_for_roll(rng, config)

        _vision._http_stats["raw_http_successes"] += 1
        n_images = _count_images_in_payload(payload)
        if n_images > 1:
            body = {"results": [_fake_single_result(rng, config.no_food_rate) for _ in range(n_images)]}
        else:
            body = _fake_single_result(rng, config.no_food_rate)
        return json.dumps(body)

    return fake_gemini_rest_request


_original_transport = None  # set by install(), consumed by restore_if_safe()


def install(config: MockGeminiConfig | None = None) -> MockGeminiConfig:
    """Swaps in the fake transport. Pairs with restore_if_safe() below -
    deliberately NOT a plain context manager, because gemini_queue.py's
    workers are long-lived background asyncio Tasks (started once by
    start_workers() and never stopped): a job the load-test harness gave
    up waiting on (per-job timeout) can still be sitting in a model's
    real queue, and the worker will keep processing that backlog on its
    own schedule (real pacing/backoff/circuit-breaker delays, possibly
    minutes) long after the harness's own tasks have all resolved. If we
    restored the real transport on a simple `with` block exit, a
    straggler like that would fire a genuine, unmocked HTTP request
    against a possibly-absent GEMINI_API_KEY. See restore_if_safe()."""
    global _original_transport
    config = config or MockGeminiConfig()
    _original_transport = _vision._gemini_rest_request
    _vision._gemini_rest_request = _make_fake_transport(config)
    return config


def is_installed() -> bool:
    return _original_transport is not None


async def restore_if_safe(drain_timeout: float = 60.0, poll_interval: float = 0.5) -> tuple[bool, int]:
    """Waits (up to drain_timeout) for every per-model queue to actually
    empty, then restores the real transport only if that succeeded.
    Returns (restored, queue_depth_at_end). If the backlog hasn't
    drained in time, the mock is deliberately left installed - safe by
    default, since this process is about to print its report and exit
    (or the caller can call this again later) rather than ever risk a
    background straggler making a real network call."""
    import asyncio
    import gemini_queue

    deadline = time.monotonic() + drain_timeout
    depth = gemini_queue.get_stats_summary().get("queue_depth", 0)
    while depth > 0 and time.monotonic() < deadline:
        await asyncio.sleep(poll_interval)
        depth = gemini_queue.get_stats_summary().get("queue_depth", 0)

    if depth > 0:
        return False, depth

    # One more short grace tick: queue_depth==0 only means nothing is
    # WAITING in the queue - a worker can still be mid-flight on the
    # batch it already dequeued (pacing wait, HTTP call, or backoff
    # sleep). There's no public signal for "worker currently busy", so
    # this is a best-effort extra pause, not a guarantee.
    await asyncio.sleep(poll_interval)
    depth = gemini_queue.get_stats_summary().get("queue_depth", 0)
    if depth > 0:
        return False, depth

    global _original_transport
    if _original_transport is not None:
        _vision._gemini_rest_request = _original_transport
        _original_transport = None
    return True, 0
