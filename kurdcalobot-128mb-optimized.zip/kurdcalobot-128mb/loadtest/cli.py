#!/usr/bin/env python3
# loadtest/cli.py
#
# Command-line entry point. Run from the project root (the directory
# containing bot.py/gemini_queue.py/vision.py) as:
#
#   python3 -m loadtest.cli --mode mock --pattern burst --users 100
#
# See loadtest/README.md for full examples.

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys

# Make sure the project root (parent of this package) is importable as
# a plain module path, since gemini_queue/vision are top-level modules
# there, not part of this package.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from loadtest.mock_gemini import MockGeminiConfig
from loadtest.runner import LoadTestConfig, print_report, run_load_test


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Load-test KurdCaloBot's queue/rate-limit/Gemini pipeline without touching production code or data."
    )
    p.add_argument("--mode", choices=["mock", "real"], default="mock",
                    help="mock: fake Gemini transport, safe to hammer. real: genuine Gemini API calls, spends real quota.")
    p.add_argument("--pattern", choices=["burst", "ramp", "sustained"], default="burst")

    p.add_argument("--users", type=int, default=50, help="number of unique synthetic users")
    p.add_argument("--jobs-per-user", type=int, default=1, help="used by burst/ramp patterns")

    p.add_argument("--ramp-seconds", type=float, default=15.0, help="pattern=ramp: time to ramp up to full arrival rate")
    p.add_argument("--jobs-per-second", type=float, default=2.0, help="pattern=sustained: steady arrival rate")
    p.add_argument("--duration-seconds", type=float, default=30.0, help="pattern=sustained: how long to sustain it")

    p.add_argument("--per-job-timeout", type=float, default=120.0, help="give up waiting on one job after this long (marks it 'lost')")
    p.add_argument("--drain-timeout", type=float, default=60.0,
                    help="mock mode only: after scheduling ends, how long to wait for background queue "
                         "backlog to empty before it's safe to hand back the real Gemini transport")
    p.add_argument("--duplicate-rate", type=float, default=0.0, help="probability a job reuses a prior image, to exercise the dedup cache")
    p.add_argument("--image-size-px", type=int, default=16)
    p.add_argument("--seed", type=int, default=12345, help="random seed for reproducible runs (mock errors, image content, image reuse)")

    # Mock-Gemini tuning (ignored in real mode)
    p.add_argument("--mock-error-rate", type=float, default=0.05)
    p.add_argument("--mock-rate-limit-share", type=float, default=0.6)
    p.add_argument("--mock-server-error-share", type=float, default=0.3)
    p.add_argument("--mock-hard-error-share", type=float, default=0.1)
    p.add_argument("--mock-latency-mean", type=float, default=0.6)
    p.add_argument("--mock-latency-jitter", type=float, default=0.35)
    p.add_argument("--mock-no-food-rate", type=float, default=0.03)

    # Watchdog
    p.add_argument("--watchdog-window-seconds", type=float, default=20.0)
    p.add_argument("--watchdog-min-samples", type=int, default=15)
    p.add_argument("--watchdog-error-threshold", type=float, default=0.5)
    p.add_argument("--watchdog-resume-threshold", type=float, default=0.25)
    p.add_argument("--watchdog-max-pause-seconds", type=float, default=90.0)
    p.add_argument("--no-watchdog-in-mock", action="store_true", help="disable the auto-stop watchdog for mock runs")

    # Real-mode safety gate
    p.add_argument("--yes-i-want-to-hit-real-gemini", action="store_true",
                    help="required to actually run --mode real; refuses to run without it")

    p.add_argument("--json-out", type=str, default=None, help="also write the full report as JSON to this path")
    p.add_argument("-v", "--verbose", action="store_true")
    return p


def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    # Quiet down noisy per-request logging from the production modules
    # unless -v was requested - a 500-user burst logs a LOT per photo.
    if not args.verbose:
        logging.getLogger("vision").setLevel(logging.WARNING)
        logging.getLogger("gemini_queue").setLevel(logging.WARNING)

    if args.mode == "real" and not args.yes_i_want_to_hit_real_gemini:
        print(
            "Refusing to run --mode real without --yes-i-want-to-hit-real-gemini.\n"
            "Real mode makes genuine calls against your GEMINI_API_KEY's quota.",
            file=sys.stderr,
        )
        return 2

    mock_config = MockGeminiConfig(
        error_rate=args.mock_error_rate,
        rate_limit_share=args.mock_rate_limit_share,
        server_error_share=args.mock_server_error_share,
        hard_error_share=args.mock_hard_error_share,
        latency_mean=args.mock_latency_mean,
        latency_jitter=args.mock_latency_jitter,
        no_food_rate=args.mock_no_food_rate,
        seed=args.seed,
    )

    config = LoadTestConfig(
        mode=args.mode,
        pattern=args.pattern,
        users=args.users,
        jobs_per_user=args.jobs_per_user,
        ramp_seconds=args.ramp_seconds,
        jobs_per_second=args.jobs_per_second,
        duration_seconds=args.duration_seconds,
        per_job_timeout=args.per_job_timeout,
        drain_timeout=args.drain_timeout,
        duplicate_rate=args.duplicate_rate,
        image_size_px=args.image_size_px,
        image_seed=args.seed,
        mock_config=mock_config,
        watchdog_window_seconds=args.watchdog_window_seconds,
        watchdog_min_samples=args.watchdog_min_samples,
        watchdog_error_threshold=args.watchdog_error_threshold,
        watchdog_resume_threshold=args.watchdog_resume_threshold,
        watchdog_max_pause_seconds=args.watchdog_max_pause_seconds,
        enforce_watchdog_in_mock=not args.no_watchdog_in_mock,
        confirmed_real_run=args.yes_i_want_to_hit_real_gemini,
    )

    report = asyncio.run(run_load_test(config))
    print_report(report)

    if args.json_out:
        import json
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f"\nFull report written to {args.json_out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
