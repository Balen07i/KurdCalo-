# loadtest/metrics.py
#
# Collects per-job outcomes and periodic pipeline snapshots during a
# load test run, and turns them into a summary report. Reads ONLY the
# real pipeline's public surface (gemini_queue.get_stats_summary()) for
# anything aggregate - it never pokes gemini_queue's private module
# state, so this stays a black-box test of the same API bot.py uses.

from __future__ import annotations

import dataclasses
import statistics
import time


@dataclasses.dataclass
class JobRecord:
    job_id: int
    user_id: int
    submit_t: float
    done_t: float | None = None
    queue_position: int | None = None
    outcome: str = "pending"  # ok | no_food | failed_rate_limited | failed_other |
    # failed_queue_full | cooldown_blocked | lost_timeout | harness_error
    model_used: str | None = None
    total_attempts: int | None = None
    billable_attempts: int | None = None

    @property
    def wait_seconds(self) -> float | None:
        if self.done_t is None:
            return None
        return self.done_t - self.submit_t


class Metrics:
    def __init__(self):
        self.started_monotonic = time.monotonic()
        self.jobs: dict[int, JobRecord] = {}
        self._inflight = 0
        self._peak_inflight = 0
        self._snapshots: list[dict] = []  # periodic gemini_queue.get_stats_summary() samples
        self.stopped_early_reason: str | None = None

    # --- concurrency tracking ------------------------------------------------
    def job_started(self, job_id: int, user_id: int) -> JobRecord:
        rec = JobRecord(job_id=job_id, user_id=user_id, submit_t=time.monotonic())
        self.jobs[job_id] = rec
        self._inflight += 1
        self._peak_inflight = max(self._peak_inflight, self._inflight)
        return rec

    def job_finished(self):
        self._inflight -= 1

    @property
    def current_inflight(self) -> int:
        return self._inflight

    @property
    def peak_inflight(self) -> int:
        return self._peak_inflight

    # --- outcome recording -----------------------------------------------
    def record_cooldown_blocked(self, job_id: int, user_id: int):
        rec = self.jobs.get(job_id) or self.job_started(job_id, user_id)
        rec.done_t = time.monotonic()
        rec.outcome = "cooldown_blocked"

    def record_completion(self, job_id: int, queue_position: int, result: dict):
        rec = self.jobs[job_id]
        rec.done_t = time.monotonic()
        rec.queue_position = queue_position
        rec.model_used = result.get("model_used")
        rec.total_attempts = result.get("total_attempts")
        rec.billable_attempts = result.get("billable_attempts")
        status = result.get("status")
        if status == "ok":
            rec.outcome = "ok"
        elif status == "no_food":
            rec.outcome = "no_food"
        elif status == "failed" and result.get("reason") == "queue_full":
            rec.outcome = "failed_queue_full"
        elif status == "failed" and result.get("reason") == "rate_limited":
            rec.outcome = "failed_rate_limited"
        else:
            rec.outcome = "failed_other"

    def record_lost(self, job_id: int, user_id: int):
        rec = self.jobs.get(job_id) or self.job_started(job_id, user_id)
        rec.done_t = time.monotonic()
        rec.outcome = "lost_timeout"

    def record_harness_error(self, job_id: int, user_id: int, exc: Exception):
        rec = self.jobs.get(job_id) or self.job_started(job_id, user_id)
        rec.done_t = time.monotonic()
        rec.outcome = "harness_error"

    # --- periodic pipeline snapshots (public API only) --------------------
    def snapshot(self, stats_summary: dict):
        self._snapshots.append({
            "t": time.monotonic() - self.started_monotonic,
            "queue_depth": stats_summary.get("queue_depth", 0),
            "inflight": self._inflight,
            "per_model_health": stats_summary.get("per_model_health", {}),
        })

    def recent_outcomes(self, window_seconds: float) -> list[JobRecord]:
        cutoff = time.monotonic() - window_seconds
        return [r for r in self.jobs.values() if r.done_t is not None and r.done_t >= cutoff]

    # --- report -------------------------------------------------------------
    def build_report(self, final_stats_summary: dict) -> dict:
        done = [r for r in self.jobs.values() if r.done_t is not None]
        waits = [r.wait_seconds for r in done if r.wait_seconds is not None]
        outcome_counts: dict[str, int] = {}
        for r in done:
            outcome_counts[r.outcome] = outcome_counts.get(r.outcome, 0) + 1

        def pct(p):
            if not waits:
                return None
            return round(statistics.quantiles(waits, n=100)[p - 1], 3) if len(waits) >= 2 else round(waits[0], 3)

        peak_queue_depth = max((s["queue_depth"] for s in self._snapshots), default=0)
        peak_queue_depth = max(peak_queue_depth, final_stats_summary.get("queue_depth", 0))

        total_retries = sum(
            (r.total_attempts - 1) for r in done
            if r.total_attempts is not None and r.total_attempts > 1
        )

        return {
            "duration_seconds": round(time.monotonic() - self.started_monotonic, 2),
            "total_jobs": len(self.jobs),
            "completed": len(done),
            "still_pending": len(self.jobs) - len(done),
            "outcome_counts": outcome_counts,
            "peak_concurrency": self.peak_inflight,
            "peak_queue_depth": peak_queue_depth,
            "wait_seconds": {
                "min": round(min(waits), 3) if waits else None,
                "p50": pct(50),
                "p95": pct(95),
                "p99": pct(99),
                "max": round(max(waits), 3) if waits else None,
                "mean": round(statistics.fmean(waits), 3) if waits else None,
            },
            "estimated_retries_observed": total_retries,
            "http_layer": {
                "raw_http_attempts": final_stats_summary.get("raw_http_attempts"),
                "raw_http_429_responses": final_stats_summary.get("raw_http_429_responses"),
                "raw_http_successes": final_stats_summary.get("raw_http_successes"),
                "raw_http_other_failures": final_stats_summary.get("raw_http_other_failures"),
            },
            "dispatch_layer": {
                "successful_analyses": final_stats_summary.get("successful_analyses"),
                "no_food_results": final_stats_summary.get("no_food_results"),
                "rate_limited_failures": final_stats_summary.get("rate_limited_failures"),
                "other_failures": final_stats_summary.get("other_failures"),
                "circuit_breaker_trips": final_stats_summary.get("circuit_breaker_trips"),
                "circuit_breaker_short_circuits": final_stats_summary.get("circuit_breaker_short_circuits"),
                "queue_full_rejections": final_stats_summary.get("queue_full_rejections"),
                "cooldown_rejections": final_stats_summary.get("cooldown_rejections"),
                "rapid_fire_escalations": final_stats_summary.get("rapid_fire_escalations"),
                "cache_hit_rate_pct": final_stats_summary.get("cache_hit_rate_pct"),
                "batched_requests_saved": final_stats_summary.get("batched_requests_saved"),
            },
            "per_model_health_final": final_stats_summary.get("per_model_health", {}),
            "stopped_early_reason": self.stopped_early_reason,
            "background_jobs_pending_at_end": 0,  # overwritten by runner.py for mock-mode drain checks
        }


def format_report(report: dict) -> str:
    lines = []
    lines.append("=" * 62)
    lines.append("LOAD TEST SUMMARY")
    lines.append("=" * 62)
    lines.append(f"Duration:            {report['duration_seconds']}s")
    lines.append(f"Total jobs:          {report['total_jobs']}")
    lines.append(f"Completed:           {report['completed']}  (pending/aborted: {report['still_pending']})")
    lines.append(f"Peak concurrency:    {report['peak_concurrency']}")
    lines.append(f"Peak queue depth:    {report['peak_queue_depth']}")
    if report["stopped_early_reason"]:
        lines.append(f"⚠️  STOPPED EARLY:    {report['stopped_early_reason']}")
    if report.get("background_jobs_pending_at_end"):
        lines.append(
            f"⚠️  BACKGROUND BACKLOG: {report['background_jobs_pending_at_end']} job(s) still queued "
            f"in the pipeline after this run's per-job-timeout gave up on them (see log)."
        )
    lines.append("")
    lines.append("Outcomes:")
    for k, v in sorted(report["outcome_counts"].items(), key=lambda kv: -kv[1]):
        lines.append(f"  {k:<22} {v}")
    lines.append("")
    w = report["wait_seconds"]
    if w["mean"] is not None:
        lines.append("Wait/latency (submit -> resolved), seconds:")
        lines.append(f"  min={w['min']}  mean={w['mean']}  p50={w['p50']}  p95={w['p95']}  p99={w['p99']}  max={w['max']}")
    lines.append("")
    lines.append(f"Retries observed (extra attempts beyond the 1st): {report['estimated_retries_observed']}")
    lines.append("")
    lines.append("HTTP layer (raw calls to the Gemini transport):")
    for k, v in report["http_layer"].items():
        lines.append(f"  {k:<24} {v}")
    lines.append("")
    lines.append("Dispatch layer (gemini_queue accounting):")
    for k, v in report["dispatch_layer"].items():
        lines.append(f"  {k:<28} {v}")
    lines.append("")
    lines.append("Per-model health at end of run:")
    for model, health in report["per_model_health_final"].items():
        lines.append(f"  [{model}] {health}")
    lines.append("=" * 62)
    return "\n".join(lines)
