# loadtest/
#
# A standalone load-testing harness for KurdCaloBot's photo-analysis
# pipeline (gemini_queue.py + vision.py).
#
# THIS PACKAGE IS NEVER IMPORTED BY PRODUCTION CODE. bot.py does not
# import anything from here, and nothing in here is imported by bot.py,
# storage.py, reviewer.py, etc. It is a separate tool that imports the
# production modules (read-only, at the Python level) to drive them the
# same way bot.py does, and in mock mode temporarily monkeypatches a
# single, well-contained function on the `vision` module for the
# lifetime of one test run (see mock_gemini.py) - it never edits
# production source files.
#
# See loadtest/README.md for usage.
