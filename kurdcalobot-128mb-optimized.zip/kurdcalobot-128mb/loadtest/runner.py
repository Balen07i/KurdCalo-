# loadtest/runner.py
#
# Orchestrates one load-test run: schedules synthetic jobs according to
# a traffic pattern, submits each one through the REAL production
# pipeline (gemini_queue.submit_photo_job, plus the same per-user
# cooldown check bot.py does), collects metrics, samples pipeline health
# periodically, and enforces an auto-stop/pause watchdog.
#
# Deliberately does NOT touch storage.py (the SQLite-backed per-user
# daily nutrition limit / meal log). That system is real production
# user data, keyed by real Telegram user ids in calories.db - a load
# test has no business writing thousands of synthetic rows into it.
# The pieces genuinely under test here (queue, concurrency, rate
# limiter, retries, Gemini handling) live entirely in gemini_queue.py
# and vision.py, which this module exercises directly and completely,
# exactly as bot.py does before it ever reaches storage.py.

from __future__ import annotations

import asyncio
import dataclasses
import logging
import time

import gemini_queue

from . import mock_gemini, scenarios
from .fake_images import ImageProvider
from .metrics import Metrics, format_report

logger = logging.getLogger("loadtest")


@dataclasses.dataclass
class LoadTestConfig:
    mode: str = "mock"  # "mock" | "real"
    pattern: str = "burst"  # "burst" | "ramp" | "sustained"

    users: int = 50
    jobs_per_user: int = 1  # used by burst/ramp; ignored by sustained

    ramp_seconds: float = 15.0  # pattern="ramp"
    jobs_per_second: float = 2.0  # pattern="sustained"
    duration_seconds: float = 30.0  # pattern="sustained"

    per_job_timeout: float = 120.0
    drain_timeout: float = 60.0  # after scheduling ends, how long to wait for
    # background queue backlog to fully drain before it's safe to restore
    # the real Gemini transport in mock mode (see mock_gemini.restore_if_safe)
    snapshot_interval: float = 1.0
    image_size_px: int = 16
    duplicate_rate: float = 0.0
    image_seed: int | None = 12345

    mock_config: mock_gemini.MockGeminiConfig = dataclasses.field(
        default_factory=mock_gemini.MockGeminiConfig
    )

    # Auto-stop/pause watchdog (see WatchdogConfig below).
    watchdog_window_seconds: float = 20.0
    watchdog_min_samples: int = 15
    watchdog_error_threshold: float = 0.5  # pause if >=50% of the recent window failed/rate-limited
    watchdog_resume_threshold: float = 0.25  # resume once it drops back below this
    watchdog_check_interval: float = 2.0
    watchdog_max_pause_seconds: float = 90.0  # give up and abort if it doesn't recover in this long
    enforce_watchdog_in_mock: bool = True  # safe to leave on: mock's default error rate is low

    # Real-mode safety gate - see cli.py. Never set True by accident;
    # this is a deliberate, explicit confirmation, not a default.
    confirmed_real_run: bool = False


def _total_jobs_for(config: LoadTestConfig) -> int:
    if config.pattern == "sustained":
        return max(int(round(config.jobs_per_second * config.duration_seconds)), 0)
    return config.users * config.jobs_per_user


def _build_offsets(config: LoadTestConfig, total_jobs: int) -> list[float]:
    if config.pattern == "burst":
        return scenarios.build_offsets("burst", total_jobs=total_jobs)
    if config.pattern == "ramp":
        return scenarios.build_offsets("ramp", total_jobs=total_jobs, ramp_seconds=config.ramp_seconds)
    if config.pattern == "sustained":
        return scenarios.build_offsets(
            "sustained", jobs_per_second=config.jobs_per_second, duration_seconds=config.duration_seconds
        )
    raise ValueError(f"Unknown pattern: {config.pattern!r}")


def _synthetic_user_ids(n: int) -> list[int]:
    # Large negative range: real Telegram user ids are always positive,
    # so these can never collide with a real user's in-memory cooldown
    # state even if this were ever run in the same process as the bot
    # (it shouldn't be - see README - but this makes it structurally
    # safe rather than just documented-safe).
    base = -900_000_000_000
    return [base - i for i in range(n)]


class _Watchdog:
    """Pauses (and, if it doesn't recover, stops) new job submission
    when the recent completion window looks like Gemini/the pipeline is
    in real trouble - excessive 429s or other failures - rather than
    letting a load test blindly hammer an already-struggling backend.
    """

    def __init__(self, config: LoadTestConfig, metrics: Metrics):
        self.config = config
        self.metrics = metrics
        self.resume_event = asyncio.Event()
        self.resume_event.set()
        self.stop_event = asyncio.Event()
        self._pause_started: float | None = None

    def _should_watch(self) -> bool:
        return self.config.mode == "real" or self.config.enforce_watchdog_in_mock

    def _error_ratio(self) -> tuple[float, int]:
        recent = self.metrics.recent_outcomes(self.config.watchdog_window_seconds)
        if not recent:
            return 0.0, 0
        bad = sum(
            1 for r in recent
            if r.outcome in ("failed_rate_limited", "failed_other", "lost_timeout", "harness_error")
        )
        return bad / len(recent), len(recent)

    async def run(self, done_event: asyncio.Event):
        if not self._should_watch():
            return
        while not done_event.is_set():
            try:
                await asyncio.wait_for(done_event.wait(), timeout=self.config.watchdog_check_interval)
                return  # test finished normally
            except asyncio.TimeoutError:
                pass

            ratio, n = self._error_ratio()
            paused = not self.resume_event.is_set()

            if not paused and n >= self.config.watchdog_min_samples and ratio >= self.config.watchdog_error_threshold:
                logger.warning(
                    "[WATCHDOG] Pausing new submissions: %.0f%% of the last %d completed jobs "
                    "(over %.0fs) failed or were rate-limited (threshold %.0f%%).",
                    ratio * 100, n, self.config.watchdog_window_seconds, self.config.watchdog_error_threshold * 100,
                )
                self.resume_event.clear()
                self._pause_started = time.monotonic()
                self.metrics.stopped_early_reason = (
                    f"paused at {ratio:.0%} error rate over last {n} jobs"
                )

            elif paused:
                if ratio <= self.config.watchdog_resume_threshold:
                    logger.warning("[WATCHDOG] Error rate recovered to %.0f%% - resuming submissions.", ratio * 100)
                    self.resume_event.set()
                    self._pause_started = None
                    self.metrics.stopped_early_reason = None
                elif self._pause_started and (time.monotonic() - self._pause_started) >= self.config.watchdog_max_pause_seconds:
                    logger.error(
                        "[WATCHDOG] Error rate has not recovered after %.0fs paused - aborting the rest of this run.",
                        self.config.watchdog_max_pause_seconds,
                    )
                    self.metrics.stopped_early_reason = (
                        f"aborted: error rate still {ratio:.0%} after "
                        f"{self.config.watchdog_max_pause_seconds:.0f}s paused"
                    )
                    self.stop_event.set()
                    self.resume_event.set()  # unblock the scheduler so it can see stop_event and exit
                    return


async def _run_one_job(
    job_id: int, user_id: int, image_bytes: bytes, media_type: str,
    config: LoadTestConfig, metrics: Metrics,
):
    metrics.job_started(job_id, user_id)
    try:
        # Mirrors bot.py's handle_photo ordering exactly: per-user
        # cooldown/rapid-fire check BEFORE the queue, using the real
        # in-memory rate limiter in gemini_queue.py.
        cooldown_remaining = gemini_queue.check_user_cooldown(user_id)
        if cooldown_remaining > 0:
            gemini_queue.record_cooldown_block()
            metrics.record_cooldown_blocked(job_id, user_id)
            return

        gemini_queue.mark_user_request(user_id)
        gemini_queue.record_photo_received()

        result, queue_position, _dhash = await asyncio.wait_for(
            gemini_queue.submit_photo_job(image_bytes, media_type, []),
            timeout=config.per_job_timeout,
        )
        metrics.record_completion(job_id, queue_position, result)
    except asyncio.TimeoutError:
        logger.error("[LOADTEST] job %d timed out after %.0fs waiting on submit_photo_job", job_id, config.per_job_timeout)
        metrics.record_lost(job_id, user_id)
    except Exception as exc:
        logger.exception("[LOADTEST] job %d raised an unexpected harness-level error", job_id)
        metrics.record_harness_error(job_id, user_id, exc)
    finally:
        metrics.job_finished()


async def _snapshot_loop(metrics: Metrics, interval: float, done_event: asyncio.Event):
    while not done_event.is_set():
        try:
            await asyncio.wait_for(done_event.wait(), timeout=interval)
            return
        except asyncio.TimeoutError:
            pass
        metrics.snapshot(gemini_queue.get_stats_summary())


async def _scheduler(
    offsets: list[float], user_ids: list[int], images: ImageProvider,
    config: LoadTestConfig, metrics: Metrics, watchdog: _Watchdog,
) -> list[asyncio.Task]:
    t0 = time.monotonic()
    tasks: list[asyncio.Task] = []
    for i, offset in enumerate(offsets):
        if watchdog.stop_event.is_set():
            logger.warning("[LOADTEST] Stopping: %d of %d jobs were never submitted.", len(offsets) - i, len(offsets))
            break

        delay = (t0 + offset) - time.monotonic()
        if delay > 0:
            stop_waiter = asyncio.ensure_future(watchdog.stop_event.wait())
            done, pending = await asyncio.wait({stop_waiter}, timeout=delay)
            if not pending:
                # stop_event fired during the sleep
                for p in pending:
                    p.cancel()
                logger.warning("[LOADTEST] Stopping mid-schedule: %d of %d jobs were never submitted.", len(offsets) - i, len(offsets))
                break
            for p in pending:
                p.cancel()

        await watchdog.resume_event.wait()  # blocks here while the watchdog has us paused
        if watchdog.stop_event.is_set():
            break

        user_id = user_ids[i % len(user_ids)]
        image_bytes, media_type = images.next_image()
        tasks.append(asyncio.create_task(_run_one_job(i, user_id, image_bytes, media_type, config, metrics)))
    return tasks


async def run_load_test(config: LoadTestConfig) -> dict:
    if config.mode == "real" and not config.confirmed_real_run:
        raise RuntimeError(
            "Refusing to run in real mode without explicit confirmation "
            "(pass --yes-i-want-to-hit-real-gemini on the CLI). This mode "
            "spends real Gemini quota."
        )
    if config.mode == "real":
        import os
        if not os.environ.get("GEMINI_API_KEY"):
            raise RuntimeError("mode=real requires GEMINI_API_KEY to be set in the environment.")

    total_jobs = _total_jobs_for(config)
    if total_jobs <= 0:
        raise ValueError("This configuration produces zero jobs - check users/jobs-per-user or rate/duration.")

    offsets = _build_offsets(config, total_jobs)
    user_ids = _synthetic_user_ids(config.users)
    images = ImageProvider(size_px=config.image_size_px, duplicate_rate=config.duplicate_rate, seed=config.image_seed)

    metrics = Metrics()
    watchdog = _Watchdog(config, metrics)
    done_event = asyncio.Event()

    logger.info(
        "[LOADTEST] Starting %s/%s run: %d jobs across %d synthetic users.",
        config.mode, config.pattern, total_jobs, config.users,
    )

    gemini_queue.start_workers()

    watchdog_task = asyncio.create_task(watchdog.run(done_event))
    snapshot_task = asyncio.create_task(_snapshot_loop(metrics, config.snapshot_interval, done_event))

    if config.mode == "mock":
        mock_gemini.install(config.mock_config)

    tasks = await _scheduler(offsets, user_ids, images, config, metrics, watchdog)
    if tasks:
        await asyncio.gather(*tasks)

    done_event.set()
    await watchdog_task
    await snapshot_task

    background_pending = 0
    if config.mode == "mock":
        # Jobs the harness gave up on (per-job timeout) can still be
        # sitting in gemini_queue's real per-model queues, being worked
        # through by the persistent worker tasks on their own schedule.
        # Only safe to hand the real transport back once that backlog
        # is actually empty - see mock_gemini.restore_if_safe.
        restored, depth_remaining = await mock_gemini.restore_if_safe(config.drain_timeout)
        if not restored:
            background_pending = depth_remaining
            logger.warning(
                "[LOADTEST] %d job(s) were still queued in the background after waiting %.0fs to drain - "
                "leaving the mock Gemini transport installed for the rest of this process's lifetime so "
                "a straggler can never make a real network call. This backlog is real: it means the "
                "pipeline was still working through jobs well after this test's own per-job-timeout gave "
                "up on them.",
                depth_remaining, config.drain_timeout,
            )

    final_stats = gemini_queue.get_stats_summary()
    report = metrics.build_report(final_stats)
    report["background_jobs_pending_at_end"] = background_pending
    return report


def print_report(report: dict):
    print(format_report(report))
