# KurdCaloBot Load Tester

A standalone tool to stress-test the bot's photo-analysis pipeline
(`gemini_queue.py` + `vision.py`) under many concurrent simulated
users — **without** touching production code, production data, or a
real Telegram bot.

## What it does and does not touch

**Reused as-is (the real thing, unmodified):**
- `gemini_queue.submit_photo_job` — real per-model queues, real workers,
  real opportunistic batching, real adaptive (AIMD) pacing, real
  proactive daily-budget pacing, real circuit breaker.
- `gemini_queue.check_user_cooldown` / `mark_user_request` — the real
  per-user cooldown and rapid-fire escalation logic, called in the same
  order `bot.py` calls them.
- `vision.estimate_calories` / `estimate_calories_batch` — real retry
  loop, real backoff (including the 429-specific short retry budget),
  real JSON parsing/finalization.
- `gemini_queue.get_stats_summary()` — the same aggregate stats `/stats`
  in the bot itself would show you.

**Never touched:**
- `storage.py` / `calories.db` — the real per-user daily nutrition
  limit and meal log. A load test has no business writing thousands of
  synthetic rows into your real users' database, so this tool calls
  `gemini_queue` directly instead of going through `bot.py`'s
  `handle_photo`, which is the only place `storage.reserve_daily_slot`
  is called.
- `bot.py`, Telegram — no bot token, no Telegram API calls at all.
- `reviewer.py` — a separate second-opinion provider with its own
  quota; out of scope for testing Gemini/queue capacity.
- Nothing in `vision.py` or `gemini_queue.py` is edited. In mock mode,
  the ONE function that makes a real HTTP call
  (`vision._gemini_rest_request`) is temporarily swapped out via a
  context manager for the lifetime of a single test run, in this
  process only, and always restored afterward — see `mock_gemini.py`.

## Two modes

### Mock mode (default, safe to hammer)

```bash
cd kurdcalobot-128mb
python3 -m loadtest.cli --mode mock --pattern burst --users 100
```

No `GEMINI_API_KEY` needed. A fake transport stands in for the network
call, with configurable latency and failure rates (429 / 5xx / hard
errors), so you can safely push to 500+ simulated users and see how the
queue, pacing, batching, and circuit breaker actually behave — without
spending a single real request.

### Real mode (controlled, spends real quota)

```bash
export GEMINI_API_KEY=your-real-key
python3 -m loadtest.cli --mode real --pattern ramp --users 10 --jobs-per-user 2 \
    --ramp-seconds 20 --yes-i-want-to-hit-real-gemini
```

- Requires the explicit `--yes-i-want-to-hit-real-gemini` flag — it
  refuses to run otherwise, so a real run can never happen by accident
  (e.g. from a copy-pasted mock command).
- Sends genuinely tiny (16×16 by default), solid-color PNGs. Gemini
  reliably reports these as "no food detected" — a real, legitimate
  result that exercises the entire pipeline end-to-end for close to the
  minimum possible token cost, instead of spending quota analyzing
  real food photos just to test plumbing.
- Start small (single digits of users) and work up — real mode is for
  validating the mock-mode findings against the real API, not for
  finding your daily budget ceiling by exhausting it.
- The auto-stop watchdog (see below) is always on in real mode.

## Traffic patterns

- `--pattern burst` — every job fires at t=0. Worst case for peak
  concurrency/queue depth; tests backpressure (`MAX_QUEUE_SIZE_PER_MODEL`
  rejections) and per-user cooldown under a stampede.
- `--pattern ramp --ramp-seconds N` — arrival rate increases smoothly
  from slow to fast over N seconds. Finds the point where pacing/queueing
  starts falling behind, rather than only the single instant it breaks.
- `--pattern sustained --jobs-per-second R --duration-seconds D` — a
  steady rate for a fixed duration; the "normal heavy day" case.

Total job count for burst/ramp is `--users × --jobs-per-user`; for
sustained it's `round(jobs-per-second × duration-seconds)`, spread
round-robin across `--users` synthetic users either way.

## Auto-stop / pause watchdog

A background watchdog samples the last `--watchdog-window-seconds`
(default 20s) of completed jobs every couple of seconds. If at least
`--watchdog-min-samples` have completed and `--watchdog-error-threshold`
(default 50%) of them failed or were rate-limited, it **pauses new
submissions** (in-flight jobs are left to finish normally) and reports
why. If the error rate recovers below `--watchdog-resume-threshold`
(default 25%), it resumes automatically. If it doesn't recover within
`--watchdog-max-pause-seconds` (default 90s), the run aborts the
remaining, not-yet-submitted jobs and reports that in the summary.

This is always on in real mode. It also defaults to on in mock mode
(harmless there, since the default mock error rate is only 5% — it
only ever fires if you deliberately configure a very high
`--mock-error-rate` to test the watchdog itself); disable it with
`--no-watchdog-in-mock` if you want a mock run to push through a high
configured error rate without pausing.

## What gets reported

After every run:
- Duration, total/completed/still-pending job counts.
- Peak concurrency (jobs in flight at once) and peak queue depth
  (sampled from `get_stats_summary()` throughout the run, not just at
  the end).
- Outcome breakdown: `ok`, `no_food`, `failed_rate_limited`,
  `failed_other`, `failed_queue_full`, `cooldown_blocked`,
  `lost_timeout` (job never resolved within `--per-job-timeout`),
  `harness_error`.
- Wait/latency distribution (min/mean/p50/p95/p99/max), measured from
  the moment a job is submitted to the moment it resolves.
- Retries observed (extra attempts beyond the first, from
  `estimate_calories`'s own `total_attempts` accounting).
- The real HTTP-layer counters (`raw_http_429_responses`, etc.) and
  dispatch-layer counters (circuit breaker trips/short-circuits, queue
  full rejections, cooldown rejections, cache hit rate, batching
  savings) straight from `gemini_queue.get_stats_summary()`.
- Per-model health at the end of the run (pacing interval, circuit
  state, daily budget used/remaining).
- Whether/why the watchdog paused or aborted the run.

Add `--json-out report.json` to also save the full structured report.

## Example progression (10 → 50 → 100 → 500+)

```bash
for n in 10 50 100 250 500; do
    python3 -m loadtest.cli --mode mock --pattern burst --users "$n" --json-out "report-burst-$n.json"
done

python3 -m loadtest.cli --mode mock --pattern ramp --users 300 --jobs-per-user 1 --ramp-seconds 30
python3 -m loadtest.cli --mode mock --pattern sustained --jobs-per-second 5 --duration-seconds 120 --users 200
```

## Notes

- Model daily-budget counters (`gemini_queue`'s per-model daily usage)
  persist for the lifetime of the Python process, same as they would in
  a real deployment. Running several tests back-to-back in one process
  means later runs see the budget already partly consumed by earlier
  ones — this is realistic, not a bug, but worth knowing when comparing
  runs. Run the CLI fresh (a new process) for a clean-budget comparison.
- This tool imports `gemini_queue` and `vision` directly and does not
  require `python-telegram-bot` to be installed.
- Synthetic user ids are large negative integers, so they can never
  collide with a real (always-positive) Telegram user id even if this
  were ever run against shared in-memory state.
