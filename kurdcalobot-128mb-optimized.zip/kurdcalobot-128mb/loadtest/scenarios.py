# loadtest/scenarios.py
#
# Pure functions that turn a traffic-shape description into a list of
# scheduled offsets (seconds from test start) at which each job should
# be submitted. Kept separate from the runner/asyncio machinery so the
# shapes are easy to reason about and unit-test in isolation.

from __future__ import annotations


def burst_offsets(total_jobs: int) -> list[float]:
    """All jobs fire at t=0 - the worst case for peak concurrency and
    peak queue depth. Tests whether the queue/backpressure (MAX_QUEUE_
    SIZE_PER_MODEL rejections) and the per-user cooldown hold up when
    everyone shows up at once."""
    return [0.0] * total_jobs


def ramp_offsets(total_jobs: int, ramp_seconds: float) -> list[float]:
    """Linearly increasing arrival rate: job i arrives at a time chosen
    so that arrivals accelerate smoothly from slow to fast over
    ramp_seconds. Tests the point at which the pipeline's pacing/
    backpressure starts to fall behind rather than the single instant
    it breaks."""
    if total_jobs <= 0:
        return []
    if ramp_seconds <= 0:
        return burst_offsets(total_jobs)
    # Arrival i lands at ramp_seconds * sqrt(i / total_jobs): sparse at
    # the start, dense near the end - a linear ramp in INSTANTANEOUS
    # rate corresponds to a sqrt curve in cumulative arrival time.
    return [ramp_seconds * ((i / total_jobs) ** 0.5) for i in range(total_jobs)]


def sustained_offsets(jobs_per_second: float, duration_seconds: float) -> list[float]:
    """Steady, evenly-spaced arrivals for the full duration - the
    "normal heavy day" case, as opposed to burst/ramp's stress
    extremes."""
    if jobs_per_second <= 0 or duration_seconds <= 0:
        return []
    total_jobs = int(round(jobs_per_second * duration_seconds))
    if total_jobs <= 0:
        return []
    interval = 1.0 / jobs_per_second
    return [i * interval for i in range(total_jobs)]


def build_offsets(pattern: str, **kwargs) -> list[float]:
    if pattern == "burst":
        return burst_offsets(kwargs["total_jobs"])
    if pattern == "ramp":
        return ramp_offsets(kwargs["total_jobs"], kwargs["ramp_seconds"])
    if pattern == "sustained":
        return sustained_offsets(kwargs["jobs_per_second"], kwargs["duration_seconds"])
    raise ValueError(f"Unknown traffic pattern: {pattern!r}")
