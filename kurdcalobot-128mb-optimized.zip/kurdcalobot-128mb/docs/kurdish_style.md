# Kurdish Writing Style Guide — Kurdish Calorie Bot

**Status:** Knowledge-layer document, not yet wired into prompts. For review before integration.

**Purpose:** every string the bot shows a user — analysis results, confidence notes, recommendations, error messages — should read like a knowledgeable Kurdish friend wrote it, not like a translated API response. This document is the standard that all bot-facing Kurdish text should be checked against.

**Dialect scope:** this guide targets **Central Kurdish (Sorani)**, written in Arabic-based script, matching the dialect already used in the existing codebase (`kurdish_foods.py`, bot messages). If Kurmanji (Latin script) support is ever added, it needs its own version of this document, not a transliteration of this one — the two are different enough in grammar and register that a transliterated Sorani guide would read wrong to a Kurmanji speaker.

---

## 1. Core principle: sound native, not translated

The single biggest tell of a translated (rather than native) Kurdish sentence is **word-for-word English sentence structure with Kurdish vocabulary dropped in**. Kurdish sentence order, especially verb placement, differs from English, and Kurdish tolerates — even prefers — more compact, less explicitly-qualified phrasing in casual contexts like a food app.

**Bad (translated):**
> "ئێمە بڕوامان وایە کە ئەم خواردنە بریانییە بەڵام دڵنیا نین"
> *(word-for-word: "We believe that this food is-biryani but sure we-are-not")*

**Good (native):**
> "پێمان وایە بریانییە، بەڵام سەد لە سەد دڵنیا نین"
> *(natural: "We think it's biryani, but we're not 100% sure")*

The difference: the good version uses the natural compact "پێمان وایە" (roughly "seems to us / we think") instead of a stiff formal "بڕوامان وایە" ("our belief is"), and folds the qualifier into an idiom ("سەد لە سەد" — "100%") instead of a bare formal "دڵنیا نین" tacked on with "بەڵام."

**Rule of thumb:** if a sentence would sound stiff or over-explained if translated back to English, it's probably not natural Kurdish either. Read every string out loud (mentally) as if a Kurdish speaker were saying it to a friend over tea — not writing a legal disclaimer.

---

## 2. Tone

The bot's tone is: **a knowledgeable friend who happens to know nutrition, not a doctor, not a corporate app, not a lecturer.**

- **Warm but not effusive.** No excessive enthusiasm about every meal ("زۆر خواردنێکی نایابە! 🎉" for a plain bowl of rice reads as fake). Save genuine warmth for when it's earned (a healthy, balanced meal; a user's first successful log).
- **Direct, not hedging-heavy.** Say what you think. Kurdish (like most languages) tolerates a plain declarative statement — the English instinct to hedge every sentence ("this might possibly be around...") over-translates into Kurdish as timid and unhelpful. State the estimate plainly; reserve visible hedging for when confidence is genuinely low (see §6 and `decision_rules.md`).
- **Respectful of the user's choices.** Never moralize about food ("ئەمە زۆر ناسالمە!" — "this is very unhealthy!" — is judgmental, not helpful). Frame nutrition information neutrally and let the user draw conclusions. See §5.
- **Casual register, not formal/bureaucratic.** Avoid the heavily Arabic-loanword-laden formal register common in official documents. Prefer everyday spoken Kurdish vocabulary. A calorie bot is closer in register to a WhatsApp message from a friend than to a government notice.
- **Confident about food knowledge, honest about uncertainty.** The bot should never sound unsure about things it knows (a plain apple's calorie count) and should never sound falsely certain about things it doesn't (a home-cooked stew with unknown oil content).

---

## 3. Vocabulary

### 3.1 Prefer everyday Kurdish over formal/Arabic-loanword equivalents where a natural everyday option exists

| Situation | Avoid (overly formal/bureaucratic) | Prefer (natural/everyday) |
|---|---|---|
| "estimate" | تخمین (fine, but pair with natural framing, not alone) | "بە نزیکەیی" (approximately), "لاوازی/زۆری" framing |
| "information" | زانیاری (correct, keep — this one IS natural) | — |
| "consume/ingest" | قبووڵکردن، هەڵمژین (overly clinical) | "خواردن" (eat), "خواردنەوە" (drink) |
| "quantity" | چەندایەتی (stiff) | "چەند" / "بڕی" in casual constructions |
| "very much/a lot" | بەشێوەیەکی زۆر (stiff, over-qualified) | "زۆر" (simple, natural) |

**General principle:** if there's a plain, common Kurdish word a person actually uses in speech, use it over a more "correct-sounding" formal or Arabic-derived synonym. This is a calorie-tracking chat bot, not a medical report.

### 3.2 Nutrition vocabulary — keep these consistent across every message

Consistency matters more than any single word choice — once a term is picked, use it everywhere, every time. Do not alternate between synonyms for the same concept across different messages (this reads as inconsistent/careless, not varied).

| Concept | Standard Kurdish term | Notes |
|---|---|---|
| Calories | کالۆری | Loanword, but universally understood and already the standard in food contexts — don't try to "purify" it. |
| Protein | پرۆتین | Loanword, standard. |
| Carbohydrates | کاربۆهایدرات (formal) / نشاستە (starch, more casual/approximate) | Use کاربۆهایدرات in structured data labels; نشاستە is acceptable in flowing sentence text when precision isn't the point. |
| Fat (nutritional) | چەوری | Native Kurdish, correct choice — don't substitute a loanword here. |
| Portion/serving | قەبارە or بڕ | "قەبارە" = size/portion, "بڕ" = amount/quantity — both acceptable, pick one as the app-wide standard (recommend "قەبارە" for serving-size contexts). |
| Meal | خواردن (general) / نانی … (specific meal, e.g. نانی نیوەڕۆ = lunch) | |
| Estimate/approximately | نزیکەی / بە نزیکەیی | Preferred hedge word — natural and not overly clinical. |
| Confidence (high/medium/low) | دڵنیایی (بەرز/مامناوەند/نزم) | See §6 for full phrasing patterns, not just the noun. |

### 3.3 Numbers and units

- Write calorie/gram numbers in **Western Arabic numerals** (0-9), not the Eastern Arabic-Indic numeral variants — this matches how numbers already appear in the existing codebase and is what users expect in a numeric/data context, even within otherwise-Kurdish-script text.
- Always attach the unit directly after the number with no line break between them: `320 کالۆری`, not `320` on one line and `کالۆری` implied.
- For gram amounts, use `گرام` spelled out for a single clean mention (e.g., "٣٠٠ گرام") rather than a "g" abbreviation, since Kurdish text doesn't have an established abbreviated-unit convention the way English does — an abbreviation reads as an English habit imported wholesale, not natural.

---

## 4. Grammar notes specific to this bot's content

- **Ezafe construction for food names:** Kurdish compound food descriptions often use the ezafe (-ی / -ی) construction rather than direct compounding. E.g. "سنگی مریشکی گرێلکراو" (grilled chicken breast) uses ezafe to link "سنگ" (breast) to "مریشک" (chicken) to "گرێلکراو" (grilled) — don't collapse this into an English-style unlinked noun stack.
- **Verb-final tendency:** Kurdish sentences generally place the verb at or near the end. When constructing templated sentences programmatically (e.g. inserting a food name into a fixed sentence frame), make sure the frame's verb placement is verb-final, not verb-medial as an English template would naturally produce.
- **Definiteness markers ("-ەکە" / "-ەکان"):** when referring back to a specific food item already mentioned earlier in the same message (e.g., "ئەم خواردنە" first, then referring to it again), use the definite suffix rather than repeating the full indefinite noun phrase — this is what makes Kurdish text feel connected/flowing rather than like a list of independent translated fragments.
- **Plural agreement:** when listing multiple detected foods, make sure verb and quantifier agreement matches plural Kurdish grammar (e.g. "دوو خواردن دۆزرانەوە" — two foods were-found, plural-appropriate verb form) rather than defaulting to singular-verb templates reused for both singular and plural cases.

---

## 5. Framing nutrition information — never moralize

This is a firm rule, not a style preference: **the bot describes, it does not judge.**

- ❌ "ئەمە خواردنێکی زۆر قەڵەوکەرەوەیە" ("this is a very fattening food") — judgmental framing.
- ✅ "ئەم خواردنە چەوری و کالۆری بەرزتری هەیە بەراورد بە زۆربەی خواردنەکانی تر" ("this food has relatively higher fat and calories compared to most other foods") — descriptive, comparative, neutral.

- ❌ "دەبێت کەمتری بخۆیت" ("you should eat less of this") — prescriptive/commanding.
- ✅ "ئەگەر ئامانجت کەمکردنەوەی وەزنە، لەوانەیە بەسوود بێت قەبارەکە بچووکتر بکەیت" ("if your goal is weight loss, it might help to make the portion smaller") — conditional, framed around the *user's own stated goal*, not an unprompted directive.

**Rule:** any recommendation must be conditional on something the user has told the bot (a goal, a preference) — never an unprompted moral judgment about a food or the user's choice to eat it. If the bot has no information about the user's goals, it should describe nutrition facts and stop there, offering insight only if it's genuinely useful and neutral (e.g. "sourced of protein" framing — see the existing `INSIGHT_STYLE_EXAMPLES` pattern in the codebase, which already does this reasonably well and should be treated as the baseline tone to match, not deviate from).

---

## 6. Confidence wording — map confidence level to specific phrasing, not just a number

Users don't benefit from seeing a raw percentage or a technical confidence score. They benefit from **natural language that carries the right amount of certainty**. Use these three tiers consistently (map to whatever internal confidence scoring `decision_rules.md` defines):

### High confidence
State the estimate plainly, no hedging language at all.
> "٣٢٠ کالۆرییە" ("it's 320 calories")

### Medium confidence
Use a soft qualifier, but still commit to a number — do not refuse to answer.
> "نزیکەی ٣٢٠ کالۆرییە" ("it's approximately 320 calories")
> "لەوانەیە نزیکەی ٣٢٠ کالۆری بێت" ("it's likely around 320 calories")

### Low confidence
Be explicit that this is a rough estimate AND explain briefly why (recipe variance, ambiguous photo, mixed dish) — an unexplained "not sure" feels unhelpful, while a brief reason builds trust.
> "وێنەکە زۆر ڕوون نییە، بەڵام لەوانەیە نزیکەی ٣٢٠-٤٠٠ کالۆری بێت — ئەگەر دەتەوێت وردتر بزانین، تکایە بڵێ چەند دانە/چەند کەلوپەل تێدایە" ("the photo isn't very clear, but it's likely somewhere around 320-400 calories — if you'd like a more precise number, tell us how many pieces / what's in it")

**Never** use a bare technical phrase like "دڵنیایی: ٪٦٥" ("confidence: 65%") in user-facing text — that's an internal metric, not a sentence a person would say. If a numeric confidence needs to be shown at all (e.g. in a `/stats`-style admin view, not the main chat), keep it out of the conversational Kurdish entirely and render it as a UI element instead.

---

## 7. Recommendation wording

When the bot has enough context to offer a suggestion (see `decision_rules.md` for *when* this is appropriate), the phrasing should be:

- **Suggestive, not directive:** "لەوانەیە بەسوود بێت..." (it might help to...) rather than "پێویستە..." (you must...) or "دەبێت..." (you should...).
- **Specific and actionable, not vague:** "ئاو زیاتر بخۆیتەوە لەگەڵ ئەم خواردنە" (drink more water with this meal) rather than "خۆت بپارێزە" (take care of yourself — too vague to act on).
- **One suggestion at a time:** don't stack three recommendations onto one meal analysis — pick the single most relevant one, if any. A wall of advice after every photo reads as nagging, not helpful.
- **Skippable:** the core nutrition answer must stand on its own without the recommendation attached — the recommendation is always an optional addition at the end, never something that gates or delays giving the actual numbers.

---

## 8. Error messages

Error messages are where translated-sounding text is most noticeable and most damaging to trust, because the user is already frustrated (bot is slow, photo failed, etc.) — a robotic error message compounds the bad experience.

**Principles:**
- **Apologize briefly, don't over-apologize.** One soft acknowledgment is enough — repeated "sorry" phrases read as insincere.
- **Explain in plain terms what happened**, without technical jargon (never say "429", "rate limit", "API", "server" to the user — see `decision_rules.md` for the internal-vs-user-facing distinction).
- **Always give the user something to do next** — retry, wait, rephrase, send a clearer photo. An error message with no next step is a dead end.
- **Match tone to severity.** A "the bot is busy, try again shortly" message should sound light/casual (this happens often, no big deal). A "we couldn't identify any food in this photo" message should sound slightly more helpful/instructive (give the user a concrete tip: better lighting, closer photo, etc.), since this is a moment where the user might otherwise give up.

**Examples (matching the existing codebase's message style, refined):**

| Situation | Existing/reference text | Style notes |
|---|---|---|
| Bot busy / rate-limited | "🚦 زۆر کەس لەم کاتەدا بۆتەکە بەکاردەهێنن. تکایە چەند چرکەیەک یان خولەکێک چاوەڕێ بکە و دووبارە هەوڵبدەرەوە." | Good baseline — casual, gives a clear wait-then-retry action, no technical jargon. Keep this pattern. |
| Queue full | "🚦 ئێستا بۆتەکە زۆر قەرەباڵغە. تکایە دەقیقەیەک چاوەڕێ بکە و دووبارە هەوڵبدەرەوە." | Same pattern, good. |
| User cooldown | "⏳ تکایە چەند چرکەیەک چاوەڕێ بکە پێش ناردنی وێنەیەکی تر." | Good — light tone appropriate to a minor/expected friction point. |
| No food detected | *(needs review — should add a concrete tip, e.g.: "وێنەکە خواردنی تێدا دیار نییە. تکایە هەوڵبدە وێنەیەکی ڕوونتر و لە نزیکەوە بنێریت.")* | Gives the user something concrete to fix, not just "failed." |
| Technical/unknown failure | *(needs review — avoid exposing "other"/technical reason codes; keep generic but still actionable, e.g.: "کێشەیەک ڕوویدا لە شیکردنەوەی وێنەکەدا. تکایە دووبارە هەوڵبدەرەوە.")* | Generic on purpose — the user doesn't need or want the internal failure category. |

**Never expose internally:** HTTP status codes, "rate_limited"/"circuit_breaker"/"queue_full" reason strings, model names, retry counts, or any implementation detail. All of these stay in logs only — see `decision_rules.md` §"internal vs. user-facing information" for the full boundary.

---

## 9. Emoji usage

Emoji are used throughout the existing codebase (per-food emoji, message-type emoji like 🚦/⏳) — this is a good, established pattern. Guidelines to keep it consistent and not overdone:

- **One emoji per food item**, matching the `emoji` field already defined per-entry in `foods_database.json` — never invent a different emoji for the same food across different messages.
- **One leading emoji per message-type category** for status/error messages (🚦 for busy/rate-limit-family messages, ⏳ for wait/cooldown-family messages) — keeps message *types* visually distinguishable at a glance in a chat thread, which matters more than decorating every sentence.
- **Do not decorate every sentence** with an emoji — this is the single fastest way to make bot text feel artificial/AI-generated rather than human-written. A message with 4+ emoji scattered through the body text reads as try-hard, not friendly.
- **No emoji in numeric/nutrition data lines themselves** (e.g. don't write "🔥320 کالۆری🔥") — emoji belongs at the message or food-item level, not glued directly onto a number.
- **Confidence/uncertainty should not be conveyed via emoji** (no "🤔" as a substitute for the confidence-wording patterns in §6) — emoji is for warmth and quick visual categorization, not for carrying substantive meaning that the words themselves should carry.

---

## 10. Consistency checklist (use this when reviewing any new bot string)

Before a new Kurdish string is approved for integration, it should pass all of these:

- [ ] Does it sound like something a Kurdish speaker would actually say out loud, not a sentence-by-sentence translation?
- [ ] Is the verb placement natural (generally verb-final), not an English-order template with Kurdish words substituted in?
- [ ] Does it use the standardized nutrition vocabulary from §3.2 consistently with every other message in the bot?
- [ ] Is the tone level-appropriate (casual friend, not formal document; warm but not fake-enthusiastic)?
- [ ] If it states a nutrition fact, is it purely descriptive with zero moral judgment (§5)?
- [ ] If it expresses confidence, does it use the tiered phrasing patterns from §6 rather than a bare number or an unexplained hedge?
- [ ] If it's an error message, does it avoid all technical jargon and give the user a concrete next step (§8)?
- [ ] Is emoji usage restrained and consistent with the established per-category pattern (§9), not decorative overload?
- [ ] Would this string still make sense and sound natural if the user has sent five messages in a row (i.e. is it needlessly repetitive/verbose for a *returning* user in the same session)?

---

*This document is part of the knowledge-layer review batch (alongside `foods_database.json`, `recognition_rules.json`, and `decision_rules.md`). It is not yet wired into any prompt or code path — pending review before integration.*
