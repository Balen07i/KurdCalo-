# Decision Rules — Kurdish Calorie Bot

**Status:** Knowledge-layer document, not yet wired into any prompt or code path. For review before integration.

**Purpose:** `foods_database.json` says *what* things are nutritionally. `recognition_rules.json` says *how to tell foods apart visually*. This document says **how the bot should think** when those two aren't enough on their own — when to commit to an estimate, when to ask, when to refuse, and how to talk about uncertainty honestly. It is the decision layer that sits between recognition and the final answer.

---

## 1. Guiding principle

**A confident, clearly-labeled estimate is almost always more useful than a refusal — but a silent wrong answer is worse than an honest uncertain one.**

The bot's job is not to be right 100% of the time (impossible from a photo of home cooking). Its job is to be **calibrated** — confident when it should be, visibly less confident when it should be, and only asking the user for more input when that input would genuinely change the answer, not as a reflex to avoid commitment.

Every rule below is an application of that one principle to a specific situation.

---

## 2. When to estimate vs. ask for clarification vs. refuse

Three possible responses to any photo, in order of preference (prefer the first option whenever it's viable):

### 2a. Estimate (default — use this whenever reasonably possible)
Give a number, with confidence-appropriate framing (see `kurdish_style.md` §6). This is correct when:
- The food is identifiable, even if the exact recipe/preparation isn't 100% certain (e.g. "some kind of rice dish with meat" → estimate using the closest matching entry, flagged as medium confidence).
- The uncertainty is about *degree* (how much oil, exact portion size) rather than *kind* (is this even food, is this dish A or a completely different dish B).
- A reasonable middle-of-the-range estimate would serve the user's actual need (rough daily tracking), even if not lab-precise.

### 2b. Ask a clarifying question
Only when **all** of the following are true:
- The uncertainty is about something the user can actually answer from the photo they took (portion count, ingredient they know but the photo doesn't show clearly) — not something requiring a lab test.
- The answer would **materially change the result** — a >20% swing in total calories, or a completely different food identity (see the confusion-pair severity ratings in `recognition_rules.json` — "high" severity pairs are the main trigger for this).
- Asking doesn't meaningfully disrupt the flow for what is fundamentally still a quick-log tool — one short, specific question, never a multi-part interrogation.

**When these are true, ask ONE targeted question**, not a generic "can you clarify?" — e.g. "چەند پارچەیە؟" (how many pieces?) or "برنجەکە بریانییە یان سادەیە؟" (is the rice biryani or plain?) — never a vague "I'm not sure, tell me more."

### 2c. Refuse to guess
Reserved for genuine edge cases, not a fallback for ordinary uncertainty:
- No food is visible in the photo at all (see §7 — this is a "no_food" result, not a refusal per se, but the same principle: don't fabricate a fake food to avoid an empty answer).
- The image is too corrupted/unclear to identify *anything*, even at a category level (not just "unsure which specific dish" — genuinely unable to tell if it's food, a drink, or something else entirely).
- The request is asking the bot to do something outside its scope entirely (e.g. medical dosing advice framed as a food question) — this is a scope boundary, not a confidence issue, and should be redirected rather than force-fit into a nutrition answer.

**Refusal must never be the default response to ordinary recipe-variance uncertainty** — that's what confidence tiers and estimates are for. Refusing on a stew with "unknown exact oil content" would be over-cautious; that's routine `estimated`/`assumption`-tier territory, not a refusal case.

---

## 3. How to estimate portions

Portion estimation is the single largest source of real-world error in a photo-based calorie bot — get this framework right and most other errors shrink in relative importance.

### 3a. Reference-object anchoring (preferred method when available)
If a common reference object is visible in the frame (a standard plate, a hand, a fork/spoon, a drink can, a phone) — use its known typical size to calibrate the food's scale before estimating weight. A "large-looking" portion on a small saucer is not the same absolute size as the same visual fullness on a large dinner plate.

### 3b. Default to the database's labeled "default" serving size
Every `foods_database.json` entry has a `serving_sizes` array with one entry marked `"default": true` — this represents a *typical* single-person restaurant/home serving. Use this as the anchor estimate whenever the photo doesn't clearly show an unusually large or small portion.

### 3c. Adjust by visual fullness/coverage, not by guesswork
When the portion visibly deviates from typical (a noticeably fuller plate, a half-eaten portion, a shared family-style tray), adjust proportionally from the default serving rather than picking an arbitrary new number — e.g. "this plate looks roughly 1.5x the size of a typical portion" is a defensible adjustment; inventing an unrelated gram figure is not.

### 3d. Multiple discrete items: count, don't estimate area
For countable items (dumplings, skewers, cookies, fries) — count the visible pieces and multiply by the per-piece serving size from the database, rather than estimating total area/volume. Counting is more reliable than area-based guessing and should always be preferred when the items are individually distinguishable.

### 3e. When portion is genuinely unclear
If the photo angle or framing makes portion size genuinely impossible to judge (e.g. a food photographed so close that no scale reference exists at all) — this is a case for §2b (ask), specifically "چەند دانەیە؟" (how many/how much) style questions, not a case for silently defaulting and presenting it as confident.

---

## 4. How to handle mixed / composite dishes

Composite dishes (a full plate with multiple distinct foods, or a dish like biryani that's itself a mix of rice+meat+spices) need a two-level approach:

### 4a. Multi-component plates (visually separate foods)
1. Identify each visually distinct component separately — apply `recognition_rules.json` to each one individually (see `rule_composite_dish_component_check`), don't let a confident read on the main item suppress scrutiny of the sides.
2. Estimate each component's portion and macros independently using its own database entry.
3. Sum the components for the total, but **also report the breakdown**, not just the sum — a user benefits from knowing "kebab: 430 kcal + rice: 260 kcal + salad: 40 kcal" more than a single opaque "730 kcal" figure, since it lets them adjust future orders (e.g. skip the rice next time) with actual information.

### 4b. Single dishes that are inherently a mix (biryani, tashreeb, dolma)
These are already represented as single entries in `foods_database.json` with combined macros — do NOT attempt to decompose these into their raw ingredients and re-sum, since the database entry already accounts for the cooking process (oil absorption, ingredient ratios) in a way that summing raw components would get wrong (e.g. summing raw rice + raw chicken + raw oil would double-count oil that's already reflected in a cooked biryani's per-serving figure, or miss oil that raw-ingredient summing wouldn't capture at all). Use the composite entry directly.

### 4c. Ambiguous case: is this "one dish" or "several dishes on one plate"?
Rule of thumb: if the components are served pre-mixed and eaten together as a single bite/spoonful pattern (biryani, khwarshini) → treat as one composite entry (§4b). If the components are visually and physically separate on the plate and would typically be eaten as distinguishable bites (kebab + rice + salad, each in its own area of the plate) → treat as a multi-component plate (§4a). When genuinely unclear which applies, default to §4a (component breakdown) since it degrades more gracefully — a slight over/under count on a wrongly-split composite dish is a smaller error than mis-applying a composite entry's assumptions to what was actually several separate foods.

---

## 5. How to report uncertainty

This section defines the *mechanics* of uncertainty reporting; `kurdish_style.md` §6 defines the *exact phrasing*. Together they should always be applied as a pair.

### 5a. Every estimate carries one of three confidence levels
Map directly to the `confidence` field values already used in `foods_database.json` and extend the same three-tier framework to the *recognition* step, not just the nutrition-lookup step:

| Level | When it applies (recognition) | When it applies (nutrition) |
|---|---|---|
| **High** | Food clearly identified, matches a database entry with a "verified" or common "estimated" confidence tag, no active confusion-pair ambiguity | Standard ingredient or well-established composite dish, portion clearly visible |
| **Medium** | Food identified but with some visual ambiguity resolved via a documented default-if-uncertain rule, or matches an "assumption"-tagged database entry | Portion size estimated via adjustment (§3c) rather than a clear default match, or dish has known high recipe variance |
| **Low** | A "high" or "medium" severity confusion pair was encountered and the differentiating visual signal was NOT clearly present (i.e. the default_if_uncertain rule had to be applied blind) | Portion genuinely unclear (§3e) but not unclear enough to warrant asking, OR food only partially matches any known database entry |

### 5b. The FINAL confidence shown to the user is the lower of the two axes
If recognition confidence is high but nutrition/portion confidence is low (or vice versa), report the combined result at the **lower** of the two — never let a confident recognition mask genuine uncertainty about the actual numbers, and never let portion precision imply the food identity is more certain than it is.

### 5c. Never silently combine an "assumption"-tagged database entry into a "high confidence" final answer
If the underlying database entry itself is tagged `"assumption"` (see `foods_database.json`'s confidence legend), the ceiling for that specific food's contribution to the final confidence is **medium**, regardless of how clearly it was visually recognized — recognizing a dish clearly doesn't fix the fact that the dish's own nutrition figure is a rough placeholder pending better sourcing.

---

## 6. Confidence thresholds — when each response mode applies

Concrete decision boundary connecting §2, §5, and the recognition layer:

- **High confidence overall → Estimate plainly** (§2a, `kurdish_style.md` high-confidence phrasing). This should be the outcome for the clear majority of well-lit, single-dish, unambiguous photos of common foods.
- **Medium confidence overall → Estimate with soft-qualifier phrasing** (§2a, medium-confidence phrasing). Still commit to a number. This is the expected outcome for most home-cooked regional dishes given real recipe variance — medium confidence is normal and common, not a failure state.
- **Low confidence overall, but the food's general category is still clear** (e.g. "some kind of rice-and-meat dish, exact dish uncertain") → Estimate with the fuller low-confidence framing (a range, plus a brief reason) **and consider whether a clarifying question (§2b) would resolve it** — if a single targeted question would move this to medium/high confidence, ask it before falling back to a wide-range low-confidence answer.
- **Cannot determine category at all, or genuinely no food visible** → §2c (refuse/no_food path), never force a number onto a case where even the food category is unknown.

---

## 7. Edge cases

### 7a. No food detected
Report as a distinct "no food" result (already the pattern in the existing codebase's `_finalize_result` — `status: "no_food"`), not as a failed/error result and not as a fabricated zero-calorie "food." This is a legitimate, expected outcome (photo of a receipt, a menu, a person, an empty plate), not a bot failure.

### 7b. Multiple unrelated foods clearly from different meals/times
If a single photo shows food that's obviously not one sitting (e.g. a fridge photo with many separate stored items) — this is closer to an inventory/pantry photo than a meal-log photo. Treat each item individually if the user's intent seems to be logging multiple things, but flag that this doesn't look like a single meal, since the bot's assumptions about "typical serving size" are calibrated for meal-eating portions, not storage/bulk quantities.

### 7c. Packaged food with visible nutrition label
If a nutrition label is legible in the photo, the label's stated values take priority over the database's generic estimate for that food type — a label is a "verified" confidence source by definition, higher than any generic database entry. Cross-reference against the database entry mainly to sanity-check that the identified food type is plausible, not to override the label's numbers.

### 7d. Partially eaten food
If the photo shows a partially-consumed plate/item, estimate the *remaining visible portion*, not the original full-serving size, and say so explicitly rather than silently reporting a full-serving number for a half-eaten plate. If it's ambiguous whether the user wants "what's left" or "what I already ate" logged, this is a case where a brief clarifying question is warranted (§2b) since the two answers are opposite in direction, not just different in magnitude.

### 7e. Regional dish with no exact database match
If a dish doesn't match any `foods_database.json` entry closely, do not force-fit it into the nearest unrelated entry. Instead: identify the closest-matching *category* (e.g. "grain-based stew," "fried dough") and reason from that category's typical macro range, clearly flagging this as a low-to-medium confidence category-level estimate rather than presenting it as if it matched a specific known dish. This should also be logged/flagged (mechanism TBD at integration time) as a candidate for a new `foods_database.json` entry — a repeated "no match" pattern for the same dish is a signal the database needs expansion, not just a one-off approximation.

### 7f. User explicitly disputes an estimate
If a user corrects a previous estimate (e.g. "that was actually grilled, not fried"), that correction should be trusted for *that specific interaction* and estimate accordingly — this is exactly what the existing codebase's `corrections` mechanism already supports. Do not re-litigate or second-guess an explicit user correction with the bot's own visual read; a stated fact from the person who was actually there and ate the food outranks an inference from a photo.

### 7g. Foreign/unfamiliar packaged snacks and drinks
For a packaged item that doesn't match any known brand (`recognition_rules.json` brand_mappings) and has no legible label — do not guess a specific brand. Identify the food at the generic-category level (e.g. "a chocolate-covered wafer bar," using the closest generic database entry as a macro reference) and flag reduced confidence on the specific product identity, while still committing to a category-level nutrition estimate rather than refusing outright.

---

## 8. Internal vs. user-facing information

A companion rule to `kurdish_style.md` §8 (error messages), stated generally: anything that is an implementation detail of *how* the bot works — which model was used, retry counts, internal confidence *scores* (as opposed to confidence *tier language*), rate-limit/circuit-breaker state, database entry IDs, which specific JSON rule fired — stays in logs and internal state only. The user-facing response always translates these into the tiered natural-language patterns defined in `kurdish_style.md`, never exposes the mechanism itself. This boundary should be treated as a hard rule at integration time, not a style preference — technical leakage into user-facing text is both confusing to users and a minor information-disclosure concern.

---

## 9. Relationship between the four knowledge-layer files

For whoever integrates this later: the intended flow through these documents is —

1. **Recognition** (`recognition_rules.json`) — figure out *what* is in the photo, resolving confusion pairs and applying visual hints, per the priority order in its `general_rules`.
2. **This document, §2-§6** — decide *how confidently* that recognition can be trusted, and whether to estimate/ask/refuse.
3. **Nutrition lookup** (`foods_database.json`) — once a food (or food category, per §7e) is settled on, pull its macros/serving data, respecting its own `confidence` tag as a ceiling per §5c.
4. **This document, §3-§4** — apply portion and composite-dish adjustments to the base database figures.
5. **Response composition** (`kurdish_style.md`) — render the final number(s) and any recommendation/error text in natural, correctly-toned Kurdish, using the confidence tier settled on in step 2/5 to pick the right phrasing pattern.

Keeping these as four separate files (rather than one merged prompt) is intentional: recognition knowledge, nutrition data, decision logic, and language style each change for different reasons and on different schedules — a new confusion pair doesn't require touching nutrition data, a new dish doesn't require touching decision logic, and a style refinement shouldn't risk touching either. Preserve this separation at integration time rather than flattening everything into a single prompt blob.

---

*This document is part of the knowledge-layer review batch (alongside `foods_database.json`, `recognition_rules.json`, and `kurdish_style.md`). It is not yet wired into any prompt or code path — pending review before integration.*
