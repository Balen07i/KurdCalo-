# bot.py
#
# Main entry point. Run with: python bot.py
# Requires env vars: TELEGRAM_BOT_TOKEN, GEMINI_API_KEY (see .env.example)

import asyncio
import logging
import os

# Load local secrets without requiring python-dotenv (keeps the 128 MB build lightweight).
def _load_local_secrets():
    secrets_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_secrets.env")
    if not os.path.isfile(secrets_file):
        return
    try:
        with open(secrets_file, "r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('\"').strip("'")
                if key and value and key not in os.environ:
                    os.environ[key] = value
    except OSError as exc:
        logging.getLogger(__name__).warning("Could not read bot_secrets.env: %s", exc)

_load_local_secrets()

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

import storage
import knowledge
from nutrition import (
    ACTIVITY_LABELS_KURDISH,
    GOAL_LABELS_KURDISH,
    analyze_meal,
    calculate_targets,
)
import gemini_queue
from vision import MODEL_NAME, check_image_locally, optimize_image
import reviewer

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

DISCLAIMER = (
    "⚠️ ئەم ئەنجامانە خەمڵاندنن و لەوانەیە بەپێی قەبارەی خواردن و "
    "شێوازی ئامادەکردن کەمێک جیاواز بن."
)
SEPARATOR = "――――――――――――"

NO_FOOD_MESSAGE = (
    "🤔 نەمتوانی هیچ خواردنێکی ڕوونم لەم وێنەیەدا بدۆزمەوە.\n\n"
    "ئەگەر وا دەزانیت خواردن تێیدایە، تکایە وێنەیەکی ڕوونتر بنێرەوە."
)

PHOTO_TIPS_MESSAGE = (
    "❌ ببورە، نەمتوانی وێنەکە بە باشی شیکار بکەم.\n\n"
    "تکایە ئەمانە تاقی بکەرەوە:\n"
    "💡 لە شوێنێکی ڕووناکتر وێنە بگرە\n"
    "🍽️ با هەموو پلێتەکە لەناو وێنەکەدا دیار بێت\n"
    "📷 دەست لەرزۆکی کەمتر بێت (وێنەکە تیژ نەبێت)\n"
    "🔍 زۆر نزیک زووم مەکە\n\n"
    "پاشان دووبارە هەوڵبدەرەوە. 🙏"
)

HELP_MESSAGE = (
    "📖 فەرمانەکان:\n\n"
    "📸 وێنەی خواردن بنێرە بۆ شیکردنەوە\n"
    "/profile - دانانی زانیاری تەندروستیت (تەمەن، باڵا، کێش، ئامانج)\n"
    "/goal - گۆڕینی ئامانجت\n"
    "/today - کۆی ئەمڕۆ\n"
    "/history - دوایین خواردنەکانت\n"
    "/week - کۆی ئەم هەفتەیە\n"
    "/month - کۆی ئەم مانگە\n"
    "/reset - سڕینەوەی هەموو مێژووت\n"
    "/settings - ڕێکخستنەکان\n"
    "/help - ئەم لیستە"
)

WELCOME_MESSAGE = (
    "سڵاو! 👋\n\n"
    "من یارمەتیدەری تۆم بۆ ژماردنی کالۆری — تەنها وێنەیەکی خواردنەکەت بنێرە، "
    "ئەگەر چەند خواردنێک پێکەوە بن یەکە‌یەک هەڵیان دەبژێرم، پاشان کالۆری و "
    "پرۆتین و کاربۆهایدرەیت و چەوری‌یان بۆ دەخەمە ڕوو — بە کوردی، بێ "
    "بەرامبەر، بۆ هەمیشە.\n\n"
    "💡 ئەگەر چەند خواردن لەسەر یەک قاپن، وێنەیەکیان پێکەوە بنێرە — پێویست "
    "ناکات هەریەکەیان بە جیا بنێریت.\n\n"
    "پێشنیار دەکەم /profile بەکاربهێنیت بۆ دانانی ئامانجی ڕۆژانەت، "
    "بەمجۆرە دوای هەر خواردنێک پێت دەڵێم چەند ماوە.\n\n" + HELP_MESSAGE
)


# --- Onboarding (profile setup) -------------------------------------------

ONBOARDING_QUESTIONS = {
    "age": "🎂 چەند ساڵت هەیە؟ (تەنها ژمارە بنووسە، بۆ نموونە: 25)",
    "height": "📏 باڵات چەندە؟ (بە سانتیمەتر، بۆ نموونە: 175)",
    "weight": "⚖️ کێشت چەندە؟ (بە کیلۆگرام، بۆ نموونە: 70)",
}


def _sex_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("👨 نێر", callback_data="profile:sex:male"),
        InlineKeyboardButton("👩 مێ", callback_data="profile:sex:female"),
    ]])


def _goal_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔥 کەمکردنەوەی چەوری", callback_data="profile:goal:lose")],
        [InlineKeyboardButton("⚖️ پاراستنی کێش", callback_data="profile:goal:maintain")],
        [InlineKeyboardButton("💪 بەهێزکردنی ماسولکە", callback_data="profile:goal:gain")],
    ])


def _activity_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(label, callback_data=f"profile:activity:{key}")]
        for key, label in ACTIVITY_LABELS_KURDISH.items()
    ]
    return InlineKeyboardMarkup(rows)


async def _start_onboarding(update: Update, user_id: int):
    storage.set_onboarding_step(user_id, "age")
    await update.message.reply_text(
        "با دەستپێبکەین! 📝\n\n" + ONBOARDING_QUESTIONS["age"]
    )


def _format_profile_summary(user: dict) -> str:
    goal_label = GOAL_LABELS_KURDISH.get(user["goal"], user["goal"])
    return (
        "✅ پرۆفایلەکەت ئامادەیە!\n\n"
        f"🎯 ئامانج: {goal_label}\n\n"
        f"📊 ئامانجی ڕۆژانەت:\n"
        f"🔥 {user['target_kcal']} کالۆری\n"
        f"💪 {user['target_protein_g']} g پرۆتین\n"
        f"🍚 {user['target_carbs_g']} g کاربۆهایدرەیت\n"
        f"🥑 {user['target_fat_g']} g چەوری\n\n"
        f"(BMR: {user['bmr']} | TDEE: {user['tdee']})"
    )


def _finish_onboarding_if_ready(user_id: int) -> dict | None:
    """If age/sex/height/weight/goal/activity are all set, computes and
    saves targets, clears onboarding state, and returns the full profile.
    Otherwise returns None."""
    user = storage.get_user(user_id)
    required = ["age", "sex", "height_cm", "weight_kg", "goal", "activity_level"]
    if not user or any(user.get(f) is None for f in required):
        return None

    targets = calculate_targets(
        sex=user["sex"], weight_kg=user["weight_kg"], height_cm=user["height_cm"],
        age=user["age"], goal=user["goal"], activity_level=user["activity_level"],
    )
    storage.update_user_fields(user_id, onboarding_step=None, **targets)
    return storage.get_user(user_id)


# --- Basic commands ---------------------------------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(WELCOME_MESSAGE)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(HELP_MESSAGE)


async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = storage.get_user(user_id)
    if user and user.get("target_kcal"):
        await update.message.reply_text(
            _format_profile_summary(user) + "\n\nبۆ گۆڕینی زانیاریەکانت دووبارە /profile بنێرە.",
        )
        # Offer to restart, but don't force it - just start over cleanly.
        storage.update_user_fields(user_id, onboarding_step=None)
    await _start_onboarding(update, user_id)


async def goal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🎯 ئامانجی نوێت هەڵبژێرە:", reply_markup=_goal_keyboard())


async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ گۆڕینی پرۆفایل", callback_data="settings:edit_profile")],
        [InlineKeyboardButton("🗑️ سڕینەوەی مێژوو", callback_data="settings:reset_ask")],
    ])
    await update.message.reply_text("⚙️ ڕێکخستنەکان:", reply_markup=keyboard)


async def reset_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ بەڵێ، بسڕەوە", callback_data="settings:reset_confirm"),
        InlineKeyboardButton("❌ نەخێر", callback_data="settings:reset_cancel"),
    ]])
    await update.message.reply_text(
        "🗑️ دڵنیایت لە سڕینەوەی هەموو مێژووی خواردنەکانت؟ ئەمە ناگەڕێتەوە.",
        reply_markup=keyboard,
    )


# --- Tracking commands --------------------------------------------------

def _progress_line(label_emoji: str, label: str, consumed: int, target: int | None) -> str:
    if target:
        remaining = target - consumed
        return f"{label_emoji} {label}: {consumed} / {target} ({'+' if remaining < 0 else ''}{remaining} ماوە)"
    return f"{label_emoji} {label}: {consumed}"


async def today(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    totals = storage.get_today_total(user_id)
    user = storage.get_user(user_id)

    lines = [f"📊 کۆی ئەمڕۆ ({totals['meal_count']} خواردن)\n"]
    lines.append(_progress_line("🔥", "کالۆری", totals["kcal"], user and user.get("target_kcal")))
    lines.append(_progress_line("💪", "پرۆتین", totals["protein_g"], user and user.get("target_protein_g")))
    lines.append(_progress_line("🍚", "کاربۆهایدرەیت", totals["carbs_g"], user and user.get("target_carbs_g")))
    lines.append(_progress_line("🥑", "چەوری", totals["fat_g"], user and user.get("target_fat_g")))

    if not (user and user.get("target_kcal")):
        lines.append("\nℹ️ بۆ بینینی ئامانجی ڕۆژانەت، /profile بەکاربهێنە.")

    _, used_today, daily_limit = storage.check_daily_limit(user_id)
    lines.append(f"\n📸 شیکردنەوەی وێنە: {used_today}/{daily_limit} بۆ ئەمڕۆ")

    await update.message.reply_text("\n".join(lines))


async def week(update: Update, context: ContextTypes.DEFAULT_TYPE):
    totals = storage.get_week_total(update.effective_user.id)
    avg = totals["kcal"] // 7
    await update.message.reply_text(
        f"📊 کۆی ئەم هەفتەیە\n"
        f"🔥 {totals['kcal']} کالۆری (تێکڕای ڕۆژانە: {avg})\n"
        f"💪 {totals['protein_g']} g پرۆتین\n"
        f"🍚 {totals['carbs_g']} g کاربۆهایدرەیت\n"
        f"🥑 {totals['fat_g']} g چەوری"
    )


async def month(update: Update, context: ContextTypes.DEFAULT_TYPE):
    totals = storage.get_month_total(update.effective_user.id)
    avg = totals["kcal"] // 30
    await update.message.reply_text(
        f"📊 کۆی ئەم مانگە\n"
        f"🔥 {totals['kcal']} کالۆری (تێکڕای ڕۆژانە: {avg})\n"
        f"💪 {totals['protein_g']} g پرۆتین\n"
        f"🍚 {totals['carbs_g']} g کاربۆهایدرەیت\n"
        f"🥑 {totals['fat_g']} g چەوری"
    )


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Bot-wide runtime stats (not per-user) - operator-facing observability.
    Not gated by any admin check since this app has no auth concept yet;
    if you want to restrict it later, check update.effective_user.id
    against your own Telegram user ID here.
    """
    s = gemini_queue.get_stats_summary()
    real_gemini_requests = s["successful_analyses"] + s["no_food_results"] + s["other_failures"] + s["rate_limited_failures"]
    await update.message.reply_text(
        f"📈 ئاماری کارکردن (تیمی {s['uptime_minutes']} خولەک):\n"
        f"🤖 مۆدێل: {MODEL_NAME}\n\n"
        f"📥 کۆی وێنەی وەرگیراو: {s['total_photos_received']}\n"
        f"📸 کۆی داواکاریەکانی گەیشتوو بۆ نۆرە: {s['total_submitted']}\n"
        f"📡 داواکاری ڕاستەقینەی Gemini: {real_gemini_requests}\n"
        f"📶 ئاستی HTTP ڕاستەقینە: هەوڵ {s['raw_http_attempts']}، "
        f"سەرکەوتوو {s['raw_http_successes']}، 429 {s['raw_http_429_responses']}، "
        f"هەڵەی تر {s['raw_http_other_failures']}\n\n"
        f"🚫 ڕاگیراو بە سنووری ڕۆژانە: {s['daily_limit_blocks']}\n"
        f"⏳ ڕاگیراو بە کوڵداندنەوە: {s['cooldown_rejections']}\n\n"
        f"♻️ کاش هیت (وردەکاری): {s['cache_hits']}\n"
        f"🧩 کاش هیت (نزیک وێنە): {s['phash_cache_hits']}\n"
        f"📦 داواکاری قرزکراو بە batch: {s['batched_requests_saved']}\n"
        f"🪟 بەشداریکردن لە دیمەنی چاوەڕوانی batch: {s['batch_window_joins']}\n"
        f"📊 ڕێژەی کاش: {s['cache_hit_rate_pct']}%\n\n"
        f"✅ سەرکەوتوو: {s['successful_analyses']}\n"
        f"🤔 هیچ خواردن نەدۆزرایەوە: {s['no_food_results']}\n"
        f"🚦 هەڵەی سنووری داواکاری (ڕاستەقینە): {s['rate_limited_failures']}\n"
        f"⛔ کورتکردنەوەی خێرا (پشکنین نەکراوە): {s['circuit_breaker_short_circuits']}\n"
        f"❌ هەڵەی تر: {s['other_failures']}\n"
        f"🔁 قەڵبی سنووردار کراوە: {s['circuit_breaker_trips']} جار\n"
        f"⚡ کەمکردنەوەی خێرایی بۆ بەکارهێنەرانی خێرا: {s['rapid_fire_escalations']}\n\n"
        + "".join(
            f"🎛️ {model}: {health['daily_used']}/{health['daily_budget']} ڕۆژانە "
            f"(ماوە: {health['daily_remaining']})، RPM {health['rpm_limit']}، "
            f"خێرایی {health['pacing_interval']}s، "
            f"{'🔴 داخراو' if health['circuit_open'] else '🟢 کراوە'}\n"
            for model, health in s["per_model_health"].items()
        )
        + f"📥 قەبارەی نۆرە: {s['queue_depth']}\n"
        f"📏 تێکڕای قەبارەی نۆرە لە کاتی وەرگرتن: {s['avg_queue_depth_at_pickup']} "
        f"(زۆرترین: {s['queue_depth_max']})\n"
        f"🔀 هەلی batch کردن: {s['batching_opportunities']} لە کۆی {s['queue_depth_samples']}\n\n"
        f"📦 batch (کۆی گشتی): {s['total_batches']} (وێنە تێیدا: {s['photos_in_batches']})، "
        f"تاک-وێنە: {s['single_photo_dispatches']}\n"
        f"📐 تێکڕای وێنە بۆ هەر داواکارییەک: {s['avg_photos_per_request']} "
        f"(زۆرترین batch: {s['max_batch_size']}، بەکارهێنان: {s['batch_utilization_pct']}%)\n"
        f"🪟 پەنجەرەی کۆکردنەوە: {s['batch_window_ms']}ms\n"
        f"💾 بیرگە: {s['cached_entries']} خواردن، {s['tracked_users']} بەکارهێنەر"
    )

    ab_data = storage.get_model_ab_comparison()
    if len(ab_data) > 1:  # only worth showing once there's real split data
        ab_lines = ["\n\n🧪 بەراوردی A/B تاقیکردنەوە:"]
        for row in ab_data:
            total = row["total_meals"]
            high_conf_pct = round(row["high_confidence_count"] / total * 100, 1) if total else 0
            wrong_pct = round(row["wrong_feedback_count"] / total * 100, 1) if total else 0
            ab_lines.append(
                f"\n🤖 {row['model_used']}: {total} خواردن\n"
                f"   🎯 دڵنیایی بەرز: {high_conf_pct}%\n"
                f"   👎 هەڵە (feedback): {wrong_pct}%"
            )
        await update.message.reply_text("".join(ab_lines))


async def history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    meals = storage.get_recent_meals(update.effective_user.id, limit=10)
    if not meals:
        await update.message.reply_text("هێشتا هیچ خواردنێکت تۆمار نەکردووە.")
        return

    lines = ["🕒 دوایین خواردنەکانت:\n"]
    for m in meals:
        time_str = m["created_at"][:16].replace("T", " ")
        lines.append(f"• {time_str} — {m['food_name_kurdish']} ({m['kcal']} کالۆری)")

    await update.message.reply_text("\n".join(lines))


# --- Meal result formatting ----------------------------------------------

def build_feedback_keyboard(meal_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("👍 ڕاستە", callback_data=f"fb:{meal_id}:correct"),
        InlineKeyboardButton("👎 هەڵەیە", callback_data=f"fb:{meal_id}:wrong"),
        InlineKeyboardButton("✏️ ڕاستکردنەوە", callback_data=f"fb:{meal_id}:fix"),
    ]])


# --- Item-by-item correction (Stage 2) ------------------------------------
#
# Reviews a meal's foods ONE AT A TIME (✅/❌ per item) instead of asking
# the user to retype the whole meal. Correcting an item's IDENTITY never
# calls Gemini again - it's resolved locally against the knowledge-layer
# glossary (data/foods_database.json), the same static data vision.py's
# own prompt already uses. If a typed correction doesn't match anything
# in the glossary, the name is still updated (respecting what the user
# actually typed) but the numbers are deliberately left as Gemini's
# original estimate, never fabricated from nothing - see
# _build_corrected_food's docstring for the full reasoning.
#
# CORRECTION_MATCH_CUTOFF is deliberately STRICTER than
# knowledge.find_glossary_match's own default (0.6, tuned for matching
# GEMINI's phrasing - already close to a real food name most of the
# time). A real bug found during testing: the default cutoff let a
# genuinely novel user-typed word ("چەلاو", not yet in the glossary)
# fuzzy-match an unrelated food ("بەقلاوا"/baklava, ratio 0.667) purely
# by coincidental character overlap, which would have silently swapped
# in baklava's nutrition under the user's own typed correction. 0.82
# rejects that (0.667 < 0.82) while still catching genuine near-typos of
# a real glossary term (a one-character-swap typo of a real alias scored
# 0.83-0.87 in testing) - verified with both cases as regression tests.
CORRECTION_MATCH_CUTOFF = 0.82

def _correction_review_keyboard(meal_id: int, index: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ ڕاستە", callback_data=f"corr:{meal_id}:{index}:yes"),
        InlineKeyboardButton("❌ هەڵەیە", callback_data=f"corr:{meal_id}:{index}:no"),
    ]])


def _format_correction_prompt(food: dict) -> str:
    return f"{food.get('emoji', '🍽️')} {food.get('name_kurdish', '؟')}\nئەمە ڕاستە؟"


def _infer_grams_from_food(food: dict) -> float | None:
    """
    Backs out the physical portion (grams) an already-analyzed food item
    represents, from Gemini's own kcal number divided by the ORIGINALLY
    matched food's per-100g density - so a later identity correction can
    scale the CORRECT food's nutrition to the SAME portion, instead of
    replacing it with a flat "one typical serving" figure regardless of
    how much was actually on the plate. Same principle (and the same
    reasoning for why it's not derived from parsing portion_kurdish's
    free-text Kurdish string) as reviewer.py's _infer_portion_grams -
    duplicated in full here rather than imported, so this core
    correction-workflow feature doesn't depend on reviewer.py (an
    optional, separately-toggled module) remaining unchanged or even
    present. Returns None when it can't be computed reliably.
    """
    orig_id = food.get("food_id")
    if not orig_id:
        return None
    orig_entry = knowledge.get_food(orig_id)
    if not orig_entry:
        return None
    per100 = orig_entry.get("nutrition_per_100g") or {}
    kcal_per_100g = per100.get("kcal")
    kcal = food.get("kcal")
    if not isinstance(kcal_per_100g, (int, float)) or kcal_per_100g <= 0:
        return None
    if not isinstance(kcal, (int, float)) or kcal <= 0:
        return None
    grams = (kcal / kcal_per_100g) * 100.0
    return grams if 0 < grams <= 3000 else None


def _build_corrected_food(original_food: dict, typed_text: str) -> dict:
    """
    Resolves a user-typed correction LOCALLY, in two tiers, no Gemini call
    at any point - see the module note below for why a Gemini fallback
    was deliberately not added even for the "genuinely unknown" case.

    Tier 1 - static glossary (knowledge.find_glossary_match): the
    authoritative source of truth. If matched, the food's IDENTITY is
    fully replaced (name, emoji, food_id) and its NUTRITION is fully
    replaced too, scaled to the same portion the original item had (see
    _infer_grams_from_food) - never a same-name-different-numbers or
    same-numbers-different-name half-correction. This is the direct fix
    for the failure mode this system exists to prevent: a correction from
    "تریشک" to "چەلاو" (or "هەنگوین" to "شەربەتی توو") must not keep the
    ORIGINAL food's calories/macros under the NEW name.

    Tier 2 - trusted alias memory (storage.get_resolved_alias_food_id):
    checked only if tier 1 finds nothing. Reuses a food_id that a PAST
    correction already resolved via tier 1, for a differently-spelled
    request naming the same food - e.g. if "چەلۆ" was previously
    corrected-and-resolved by enough independent users, a later "چەلاو"
    submission (same food, different spelling) can reuse that instead of
    failing to resolve again. Still the static glossary's own numbers
    doing the work either way - this tier is about REUSING a past
    resolution, not creating a new one from user say-so.

    If BOTH tiers come up empty: the typed name is still shown (respecting
    what the user entered, not silently rejecting it) but the macros stay
    exactly as Gemini's original estimate for the OLD identity, flagged
    unresolved_correction=True - never invented, never guessed. This is
    the honest outcome for a food that's genuinely not anywhere in local
    knowledge yet: it becomes a candidate for the alias-memory system
    (recorded by the caller) rather than a fabricated number.
    """
    match = knowledge.find_glossary_match(typed_text, cutoff=CORRECTION_MATCH_CUTOFF)
    resolved_food_id = match["id"] if match else storage.get_resolved_alias_food_id(typed_text)
    new_food = dict(original_food)

    if not resolved_food_id:
        new_food["name_kurdish"] = typed_text
        new_food["matched_glossary"] = False
        new_food["food_id"] = None
        new_food["unresolved_correction"] = True
        return new_food

    entry = knowledge.get_food(resolved_food_id) or {}
    names = entry.get("names", {})
    new_food["name_kurdish"] = names.get("kurdish", typed_text)
    new_food["emoji"] = entry.get("emoji", original_food.get("emoji", "🍽️"))
    new_food["food_id"] = resolved_food_id
    new_food["matched_glossary"] = True
    new_food.pop("unresolved_correction", None)

    grams = _infer_grams_from_food(original_food)
    per100 = entry.get("nutrition_per_100g") or {}
    if grams is not None and all(isinstance(per100.get(k), (int, float)) for k in ("kcal", "protein_g", "carbs_g", "fat_g")):
        factor = grams / 100.0
        new_food["kcal"] = round(per100["kcal"] * factor)
        new_food["protein_g"] = round(per100["protein_g"] * factor)
        new_food["carbs_g"] = round(per100["carbs_g"] * factor)
        new_food["fat_g"] = round(per100["fat_g"] * factor)
        new_food["portion_kurdish"] = f"~{round(grams)} گرام (خەمڵێنراو)"
    else:
        serving = entry.get("nutrition_per_serving") or {}
        if all(isinstance(serving.get(k), (int, float)) for k in ("kcal", "protein_g", "carbs_g", "fat_g")):
            new_food["kcal"] = serving["kcal"]
            new_food["protein_g"] = serving["protein_g"]
            new_food["carbs_g"] = serving["carbs_g"]
            new_food["fat_g"] = serving["fat_g"]

    return new_food


def _meal_result_from_row(meal_id: int, foods: list[dict]) -> dict | None:
    """Rebuilds a format_result()-shaped dict from a meal row + its
    (possibly just-corrected) foods list, for showing the recalculated
    result after an item-by-item correction finishes."""
    meal = storage.get_meal(meal_id)
    if not meal:
        return None
    return {
        "foods": foods,
        "total_kcal": meal["kcal"], "total_protein_g": meal["protein_g"],
        "total_carbs_g": meal["carbs_g"], "total_fat_g": meal["fat_g"],
        "confidence": meal.get("confidence") or "مامناوەند",
        "note_kurdish": meal.get("note_kurdish") or "",
        "insight_kurdish": meal.get("insight_kurdish") or "",
        "alternatives": [],
    }


def _format_food_block(food: dict) -> str:
    return (
        f"{food['emoji']} {food['name_kurdish']} — {food['portion_kurdish']}\n\n"
        f"🔥 کالۆری: {food['kcal']}\n"
        f"💪 پرۆتین: {food['protein_g']} g\n"
        f"🍚 کاربۆهایدرەیت: {food['carbs_g']} g\n"
        f"🥑 چەوری: {food['fat_g']} g"
    )


def _format_alternatives(alternatives: list[dict]) -> str:
    if not alternatives:
        return ""
    lines = ["\n\n🤔 دڵنیا نیم لە هەندێک بەشی خواردنەکە:"]
    for alt in alternatives:
        lines.append(
            f"• {alt.get('scenario_kurdish', '')} → نزیکەی {alt.get('total_kcal', 0)} کالۆری "
            f"({alt.get('explanation_kurdish', '')})"
        )
    return "\n".join(lines)


def format_result(result: dict, user: dict | None) -> str:
    foods = result["foods"]
    food_blocks = "\n\n".join(_format_food_block(f) for f in foods)

    totals_block = ""
    if len(foods) > 1:
        totals_block = (
            f"\n\n{SEPARATOR}\n"
            f"📊 کۆی گشتی:\n"
            f"🔥 کالۆری: {result['total_kcal']}\n"
            f"💪 پرۆتین: {result['total_protein_g']} g\n"
            f"🍚 کاربۆهایدرەیت: {result['total_carbs_g']} g\n"
            f"🥑 چەوری: {result['total_fat_g']} g"
        )

    total = {
        "kcal": result["total_kcal"], "protein_g": result["total_protein_g"],
        "carbs_g": result["total_carbs_g"], "fat_g": result["total_fat_g"],
    }
    goal = user.get("goal") if user else None
    quality_line = analyze_meal(total, user, goal)

    alt_block = _format_alternatives(result.get("alternatives", []))

    return (
        f"{food_blocks}"
        f"{totals_block}"
        f"{alt_block}\n\n"
        f"🎯 ئاستی دڵنیابوونم لە ئەنجامەکە: {result['confidence']}\n\n"
        f"💬 کورتە تێبینی:\n{result['note_kurdish']}\n\n"
        f"{quality_line}\n\n"
        f"{result['insight_kurdish']}\n\n"
        f"{DISCLAIMER}"
    )


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    gemini_queue.record_photo_received()

    # Per-user cooldown check happens BEFORE we even touch the queue, so a
    # spammy user can't burn shared Gemini quota that other users need.
    cooldown_remaining = gemini_queue.check_user_cooldown(user_id)
    if cooldown_remaining > 0:
        message = (
            gemini_queue.RAPID_FIRE_MESSAGE_KURDISH
            if cooldown_remaining > gemini_queue.USER_COOLDOWN_SECONDS
            else gemini_queue.COOLDOWN_MESSAGE_KURDISH
        )
        gemini_queue.record_cooldown_block()
        await update.message.reply_text(message)
        return

    gemini_queue.mark_user_request(user_id)

    processing_msg = await update.message.reply_text("🔍 خواردنەکە شیکار دەکەم...")
    slot_reserved = False

    try:
        # Telegram generates several PhotoSize variants per upload (thumbnail,
        # medium, large, and sometimes a near-original size for high-res
        # photos) and hosts all of them on its own CDN. photo[-1] (the
        # largest) was used unconditionally before - a real, measured RAM
        # cost under burst load, since the queue holds these bytes raw (see
        # gemini_queue.py's queue.put()): 40 queued 1.5MB photos alone
        # measured at ~59MB in a dedicated test, before counting a second
        # model's own queue or baseline process memory. Requesting the
        # second-largest variant instead costs zero local CPU/decode work -
        # Telegram does the resizing on their end - and still preserves
        # enough visual detail for food/portion recognition for the vast
        # majority of photos. Falls back to the largest available variant
        # if Telegram only sent one size, so this can never index-error or
        # accidentally pick a thumbnail-tier image.
        photo_sizes = update.message.photo
        selected_index = -2 if len(photo_sizes) >= 2 else -1
        photo = photo_sizes[selected_index]
        photo_file = await photo.get_file()
        image_bytes = bytes(await photo_file.download_as_bytearray())

        # Size-distribution logging - metadata only (two numbers via the
        # logger, not the image itself, no new storage). Purpose: replace
        # the assumption-based image-size tiers used in the RAM analysis
        # with a real measured distribution from actual traffic, cheaply,
        # before deciding whether the variant change above is sufficient
        # on its own or whether real re-compression is still needed for
        # outlier-sized uploads. Deliberately simple (no reverse lookups
        # or anything that could raise) since this sits in the hot path
        # before any real validation has happened yet.
        logger.info("[PHOTO_SIZE] %d bytes (variant index %d of %d available)",
                    len(image_bytes), selected_index, len(photo_sizes))

        # Optimize BEFORE enqueueing, not inside the worker - a queue full
        # of full-size phone photos is real, avoidable memory pressure
        # under any backlog. Runs in a thread so resizing doesn't block
        # the event loop for other users mid-request.
        image_bytes = await asyncio.to_thread(optimize_image, image_bytes)

        # Local pre-filter: catches obviously-invalid images (blank/near-
        # black frames) before they'd ever cost a Gemini request OR a
        # daily-limit slot. Fails open - only rejects when near-certain.
        is_valid, reject_reason = await asyncio.to_thread(check_image_locally, image_bytes)
        if not is_valid:
            await processing_msg.edit_text(reject_reason)
            return

        # Reserve the daily-limit slot ATOMICALLY, synchronously, right
        # before submission - no `await` between the check and the
        # increment, which is what makes this race-proof under
        # concurrent_updates=True (see storage.reserve_daily_slot for the
        # full explanation of the bug this fixes).
        slot_reserved, used_today, daily_limit = storage.reserve_daily_slot(user_id)
        if not slot_reserved:
            gemini_queue.record_daily_limit_block()
            await processing_msg.edit_text(
                storage.LIMIT_REACHED_MESSAGE_KURDISH.format(used=used_today, limit=daily_limit)
            )
            return

        corrections = storage.get_trusted_aliases_for_prompt()  # Stage 2 fix: only
        # aliases MULTIPLE independent users have confirmed reach the prompt now -
        # see storage.py's "Kurdish correction memory" section for why the old
        # get_all_corrections() (unfiltered, every correction ever submitted) was
        # a real single-user-poisoning risk.
        result, queue_position, dhash_value = await gemini_queue.submit_photo_job(
            image_bytes, "image/jpeg", corrections
        )

        if queue_position > 0 and result.get("reason") != "queue_full":
            # Only worth mentioning if they actually had to wait behind
            # someone else - avoids noise for the common case.
            try:
                await processing_msg.edit_text(
                    f"🔍 لە نۆرەدایت ({queue_position} کەس لەپێش تۆن)، تکایە چاوەڕێ بکە..."
                )
            except Exception:
                pass  # non-critical - if this edit fails, just proceed silently

        if result["status"] == "ok":
            # Second-opinion review - completely separate provider/quota
            # from Gemini (see reviewer.py's module docstring). A no-op
            # when REVIEWER_API_KEY isn't set, and fails safe on any
            # error/timeout: review=None means "keep Gemini's result
            # exactly as-is", handled identically to gating skipping it.
            if reviewer.is_enabled() and reviewer.should_review(result):
                review = await reviewer.review_result(image_bytes, "image/jpeg", result)
                result = reviewer.apply_review(result, review)

            user = storage.get_user(user_id)
            meal_id = storage.log_meal(user_id, result, dhash_value)
            storage.log_analysis_fingerprint(dhash_value, result)
            await processing_msg.edit_text(
                format_result(result, user),
                reply_markup=build_feedback_keyboard(meal_id),
            )
        elif result["status"] == "no_food":
            await processing_msg.edit_text(NO_FOOD_MESSAGE)
        elif result.get("reason") == "queue_full":
            await processing_msg.edit_text(gemini_queue.QUEUE_FULL_MESSAGE_KURDISH)
        elif result.get("reason") == "rate_limited":
            await processing_msg.edit_text(gemini_queue.RATE_LIMIT_MESSAGE_KURDISH)
        else:
            await processing_msg.edit_text(PHOTO_TIPS_MESSAGE)

    except Exception:
        logger.exception("[UNEXPECTED] Error in handle_photo")
        await processing_msg.edit_text(PHOTO_TIPS_MESSAGE)
    finally:
        if slot_reserved:
            storage.release_daily_slot(user_id)


# --- Callback (button) handling -------------------------------------------

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    parts = (query.data or "").split(":")
    domain = parts[0]

    if domain == "fb":
        await _handle_feedback_callback(query, user_id, parts)
    elif domain == "corr":
        await _handle_correction_callback(query, user_id, parts)
    elif domain == "profile":
        await _handle_profile_callback(query, user_id, parts)
    elif domain == "settings":
        await _handle_settings_callback(query, user_id, parts)


async def _handle_feedback_callback(query, user_id: int, parts: list[str]):
    _, meal_id_str, choice = parts
    meal_id = int(meal_id_str)

    if choice == "correct":
        storage.set_feedback(meal_id, "correct")
        original_text = query.message.text or ""
        await query.edit_message_text(f"{original_text}\n\n✅ سوپاس! ئەمە یارمەتیمان دەدات باشتر بین.")
    elif choice == "wrong":
        storage.set_feedback(meal_id, "wrong")
        original_text = query.message.text or ""
        await query.edit_message_text(f"{original_text}\n\n📝 سوپاس بۆ ئاگادارکردنەوە!")
    elif choice == "fix":
        foods = storage.get_meal_foods(meal_id)
        if not foods:
            await query.message.reply_text(
                "ببورە، ناتوانم ئەم خواردنە ڕاستبکەمەوە (زانیاری بەردەست نییە)."
            )
            return
        storage.start_item_correction(user_id, meal_id)
        await query.message.reply_text(
            _format_correction_prompt(foods[0]),
            reply_markup=_correction_review_keyboard(meal_id, 0),
        )


async def _handle_correction_callback(query, user_id: int, parts: list[str]):
    _, meal_id_str, index_str, choice = parts
    meal_id = int(meal_id_str)
    index = int(index_str)
    foods = storage.get_meal_foods(meal_id)

    if index >= len(foods):
        return  # stale tap after the flow already finished - ignore quietly

    if choice == "yes":
        next_index = index + 1
        if next_index < len(foods):
            storage.advance_correction_index(user_id, next_index)
            await query.edit_message_text(
                _format_correction_prompt(foods[next_index]),
                reply_markup=_correction_review_keyboard(meal_id, next_index),
            )
        else:
            storage.clear_item_correction(user_id)
            result = _meal_result_from_row(meal_id, foods)
            user = storage.get_user(user_id)
            if result:
                await query.edit_message_text("✅ تازەکرایەوە:\n\n" + format_result(result, user))
    elif choice == "no":
        storage.set_awaiting_text(user_id, True)
        await query.edit_message_text(
            f"{foods[index].get('emoji', '🍽️')} {foods[index].get('name_kurdish', '؟')}\n\n"
            "تکایە ناوی ڕاستی خواردنەکە بنووسە:"
        )


async def _handle_profile_callback(query, user_id: int, parts: list[str]):
    _, field, value = parts

    if field == "sex":
        storage.update_user_fields(user_id, sex=value)
        storage.set_onboarding_step(user_id, "height")
        await query.message.reply_text(ONBOARDING_QUESTIONS["height"])
    elif field == "goal":
        storage.update_user_fields(user_id, goal=value)
        profile = _finish_onboarding_if_ready(user_id)
        if profile:
            await query.message.reply_text(_format_profile_summary(profile))
        else:
            storage.set_onboarding_step(user_id, "activity")
            await query.message.reply_text(
                "📈 ئاستی چالاکیت چۆنە؟", reply_markup=_activity_keyboard()
            )
    elif field == "activity":
        storage.update_user_fields(user_id, activity_level=value)
        profile = _finish_onboarding_if_ready(user_id)
        if profile:
            await query.message.reply_text(_format_profile_summary(profile))
        else:
            await query.message.reply_text("🎯 ئامانجت چیە؟", reply_markup=_goal_keyboard())


async def _handle_settings_callback(query, user_id: int, parts: list[str]):
    action = parts[1]

    if action == "edit_profile":
        storage.set_onboarding_step(user_id, "age")
        await query.message.reply_text("با دەستپێبکەین! 📝\n\n" + ONBOARDING_QUESTIONS["age"])
    elif action == "reset_ask":
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بەڵێ، بسڕەوە", callback_data="settings:reset_confirm"),
            InlineKeyboardButton("❌ نەخێر", callback_data="settings:reset_cancel"),
        ]])
        await query.message.reply_text(
            "🗑️ دڵنیایت لە سڕینەوەی هەموو مێژووی خواردنەکانت؟ ئەمە ناگەڕێتەوە.",
            reply_markup=keyboard,
        )
    elif action == "reset_confirm":
        storage.reset_user_history(user_id)
        await query.edit_message_text("✅ هەموو مێژووی خواردنەکانت سڕایەوە.")
    elif action == "reset_cancel":
        await query.edit_message_text("❌ هیچ شتێک نەسڕایەوە.")


# --- Free-text handling (onboarding answers + corrections) ----------------

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = (update.message.text or "").strip()
    user = storage.get_user(user_id)

    # Priority 1: an item-by-item correction awaiting a typed name takes
    # precedence over onboarding. Two sub-cases: actually awaiting text
    # (user tapped ❌ for the current item), vs. mid-flow but the ✅/❌
    # buttons are still showing (a stray text message isn't expected
    # input there - nudge instead of silently misinterpreting it).
    if user and user.get("pending_correction_meal_id"):
        meal_id = user["pending_correction_meal_id"]
        if not user.get("pending_correction_awaiting_text"):
            await update.message.reply_text("تکایە دوگمەکانی سەرەوە بەکاربهێنە ✅ / ❌")
            return

        index = user.get("pending_correction_food_index")
        foods = storage.get_meal_foods(meal_id)
        if index is None or index >= len(foods):
            storage.clear_item_correction(user_id)
            await update.message.reply_text("ببورە، کێشەیەک ڕوویدا. تکایە دووبارە هەوڵبدەرەوە.")
            return

        original_food = foods[index]
        observed_name = original_food.get("name_kurdish", "؟")
        corrected_food = _build_corrected_food(original_food, text)
        foods[index] = corrected_food

        # Record toward the Kurdish correction memory regardless of
        # whether it resolved locally - see storage.record_alias_correction's
        # docstring. Never lets a storage failure break the correction
        # the user is actively watching happen to their own meal.
        storage.record_alias_correction(user_id, observed_name, text, corrected_food.get("food_id"))
        storage.mark_fingerprint_corrected(None)  # dhash is disabled in 128 MB mode - harmless no-op

        storage.update_meal_foods(meal_id, foods)  # persist now, not just at the end -
        # so an abandoned mid-flow correction isn't lost

        next_index = index + 1
        if next_index < len(foods):
            storage.advance_correction_index(user_id, next_index)
            await update.message.reply_text(
                _format_correction_prompt(foods[next_index]),
                reply_markup=_correction_review_keyboard(meal_id, next_index),
            )
        else:
            storage.clear_item_correction(user_id)
            result = _meal_result_from_row(meal_id, foods)
            user_profile = storage.get_user(user_id)
            if result:
                await update.message.reply_text("✅ تازەکرایەوە:\n\n" + format_result(result, user_profile))
        return

    # Priority 2: an active onboarding step (age/height/weight are free text).
    step = user.get("onboarding_step") if user else None
    if step == "age":
        if text.isdigit() and 10 <= int(text) <= 100:
            storage.update_user_fields(user_id, age=int(text))
            storage.set_onboarding_step(user_id, "sex")
            await update.message.reply_text("🚻 ڕەگەزت چیە؟", reply_markup=_sex_keyboard())
        else:
            await update.message.reply_text("تکایە ژمارەیەکی دروست بنووسە (بۆ نموونە: 25)")
        return

    if step == "height":
        try:
            height = float(text)
            if not (100 <= height <= 250):
                raise ValueError
            storage.update_user_fields(user_id, height_cm=height)
            storage.set_onboarding_step(user_id, "weight")
            await update.message.reply_text(ONBOARDING_QUESTIONS["weight"])
        except ValueError:
            await update.message.reply_text("تکایە ژمارەیەکی دروست بنووسە بە سانتیمەتر (بۆ نموونە: 175)")
        return

    if step == "weight":
        try:
            weight = float(text)
            if not (30 <= weight <= 300):
                raise ValueError
            storage.update_user_fields(user_id, weight_kg=weight)
            storage.set_onboarding_step(user_id, "goal")
            await update.message.reply_text("🎯 ئامانجت چیە؟", reply_markup=_goal_keyboard())
        except ValueError:
            await update.message.reply_text("تکایە ژمارەیەکی دروست بنووسە بە کیلۆگرام (بۆ نموونە: 70)")
        return

    # No relevant state - gentle nudge instead of silence.
    await update.message.reply_text("📸 وێنەیەکی خواردن بنێرە، یان /help بنووسە بۆ بینینی فەرمانەکان.")


async def _post_init(application):
    # Must start the worker from inside the running event loop - this hook
    # is PTB's supported way to do that, runs once before polling begins.
    gemini_queue.start_workers()
    logger.info("[STARTUP] Gemini request queue worker is running")


def main():
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    storage.init_db()

    # concurrent_updates=True is essential here, not optional: PTB
    # processes updates one at a time by default and does NOT start
    # dispatching the next update until the current handler's coroutine
    # returns. Since a photo handler can legitimately await the Gemini
    # queue for a while (rate-limit retries), leaving this at the default
    # meant every OTHER user's update - including their own instant
    # "🔍 analyzing" message - waited behind whatever the current photo
    # was doing. This was the real cause of the "7 minute delay before
    # anything happens" bug. Enabling this makes every update dispatch
    # immediately into its own task; the actual Gemini call pacing and
    # rate-limit protection is still fully enforced by gemini_queue's
    # single sequential worker, completely independent of this setting.
    app = (
        Application.builder()
        .token(token)
        .post_init(_post_init)
        .concurrent_updates(True)
        .build()
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("profile", profile_command))
    app.add_handler(CommandHandler("goal", goal_command))
    app.add_handler(CommandHandler("settings", settings_command))
    app.add_handler(CommandHandler("reset", reset_command))
    app.add_handler(CommandHandler("today", today))
    app.add_handler(CommandHandler("week", week))
    app.add_handler(CommandHandler("month", month))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CommandHandler("history", history))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    logger.info("Bot starting...")
    app.run_polling()


if __name__ == "__main__":
    main()
