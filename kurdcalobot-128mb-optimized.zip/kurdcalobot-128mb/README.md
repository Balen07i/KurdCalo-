# Kurdish Calorie Bot — Setup Guide (100% Free Stack)

Two free API keys, no credit card, no paid services anywhere in this project.

## This version: analysis accuracy (Stage 1) + item-by-item correction (Stage 2)

Two independent improvements to the food-analysis pipeline, built for the 128 MB / FPS.ms deployment target - no new dependencies, no heavy libraries, no rewrites of the RPM/quota/batching/reviewer systems.

### Stage 1 - analysis accuracy (vision.py prompt + one lightweight code check)

All seven priorities addressed via the Gemini system prompt (grams-first portions with explicit false-precision warnings, edible-portion/cooked-vs-raw protein guidance, cooking-method-aware fat estimation without inventing exact oil amounts, recognition-vs-nutrition confidence separated with an explicit portion-uncertainty cap, strengthened macro-consistency wording, no more listing plain water), plus one new lightweight, zero-dependency code check:

`vision._validate_consistency()` catches exactly the reported failure (an item labeled "هەنجیر"/fig while the description talks about honey) via a word-boundary-aware scan of the food glossary against the response's own note/insight text - not an ML/embedding check, a plain regex scan over an already-loaded list. **A real gap was found while testing this**: honey itself wasn't in the food database at all, so the check couldn't have caught the actual reported example - added a `raw_honey` entry (verified-tier, standard USDA reference values) to close it. **A false positive was also found and fixed during testing**: naive substring matching flagged "شیرینترین" (sweetest) as mentioning "شیر" (milk) purely by character overlap - fixed with a word-boundary regex.

### Stage 2 - item-by-item correction, zero extra Gemini calls for confirmations or resolvable corrections

Replaces the old "retype the whole meal" correction flow with a ✅/❌ review of each detected food individually (`_handle_correction_callback`, new `corr:` callback domain). Tapping ❌ prompts for the correct name; that name is resolved **locally**, against the same static `data/foods_database.json` glossary Gemini's own prompt already uses - **no Gemini call for a resolvable correction**. If resolved, nutrition is scaled to the *same portion* the original item had (reusing the exact portion-inference principle from `reviewer.py`'s earlier fix - back the grams out from the original food's kcal/density, don't flatten to a "one serving" reference). If unresolved, the typed name is still shown (respecting what the user entered) but the numbers are left as Gemini's original estimate - never fabricated.

**A real bug was found and fixed during testing**: the glossary's default fuzzy-match tolerance (tuned for matching Gemini's own phrasing, which is normally already close to a real name) let a genuinely novel local word ("چەلاو") fuzzy-match an unrelated food ("بەقلاوا"/baklava) at a 0.667 similarity ratio - which would have silently swapped in baklava's nutrition under the user's own correction. Fixed with a stricter cutoff (0.82) specifically for user-typed corrections, verified to still catch genuine near-typos of real glossary terms.

**Kurdish correction memory** (`storage.py`'s `food_aliases`/`food_alias_votes` tables): every correction is recorded as a `candidate`, promoted to `supported` (2 independent users) then `trusted` (3+) based on **distinct users**, not repeat submissions from one person - enforced by a junction table's primary key, not application logic that could be gotten wrong. Only `trusted` aliases reach the Gemini prompt (`get_trusted_aliases_for_prompt`), fixing a real pre-existing issue: the old `get_all_corrections()` fed *every* correction ever submitted into *every* future prompt, unmoderated - a single bad-faith correction was one tap away from being treated as reliable signal for every other user. Stale, never-confirmed candidates expire after 30 days (`cleanup_stale_alias_candidates`, run opportunistically, matching the existing reservation-cleanup pattern already in this file).

All totals recalculate correctly after a correction (`storage.update_meal_foods`), verified to flow through to `/today`/`/week`/`/month`, and a migration test confirms `init_db()` upgrades a pre-existing database safely with zero data loss.

**Files changed:** `vision.py`, `storage.py`, `bot.py`, `data/foods_database.json` (+1 entry), `data/recognition_rules.json` (1 field). **Completely untouched, confirmed by diff:** `gemini_queue.py`, `reviewer.py`, `knowledge.py`, `nutrition.py`, `review_feedback.py`, `kurdish_foods.py`, and every existing command handler (`/profile`, `/today`, `/week`, `/month`, `/stats`, `/history`, `/goal`, `/settings`, `/reset`). No new environment variables, no new dependencies.

## Previous version: portion-scaling fix in the reviewer's correction path (bug fix, no new features)

**The bug (found in review before deployment, not by me):** `reviewer.apply_review()`'s correction path copied a database entry's flat `nutrition_per_serving` figure directly onto a food, regardless of what portion Gemini had actually identified. A 100g reference value would silently overwrite a 400g meal's numbers - a large, systematic nutrition-accuracy error, not a cosmetic one.

**The fix:**
- `_infer_portion_grams()` backs out the physical portion size (grams) from Gemini's own kcal estimate divided by the *originally*-matched food's `nutrition_per_100g` density - grams is a property of the portion on the plate, not of which specific food it turns out to be, so the original identification's density is the right thing to divide by even when that identification is exactly what's being corrected. Deliberately does NOT attempt to parse the free-text `portion_kurdish` string (could read "٤٠٠ گرام", "یەک پلێت", or "نادیار" - unreliable text-parsing is exactly the kind of silent guess `docs/decision_rules.md` §3e warns against).
- `_scale_nutrition_to_grams()` then scales the *corrected* food's `nutrition_per_100g` to that same inferred portion.
- **New hard requirement:** a numeric correction is now only auto-applied when the corrected entry's own `confidence` tag is `"verified"` - an `"estimated"` or `"assumption"` entry is reference/context only, per explicit instruction, even with a perfectly valid food_id and a high-confidence review.
- If either the portion can't be reliably inferred (e.g. the original food had no `food_id` to derive a density from) or the entry isn't `"verified"`, the correction is **not applied at all** - name and numbers both stay exactly as Gemini produced them, and it falls through to the existing disagreement-signal path (confidence capped down, or flagged for clarification) instead of a partial/inconsistent correction.
- Totals are recalculated from the (now correctly-scaled) per-food numbers, same as before.

**New regression tests** (in addition to re-running every existing reviewer.py test): a 400g correction case matching the exact bug report (ground beef → lamb, portion inferred as 400g, scaled to 1032 kcal - not the flat 258 kcal a "per serving" copy would have given), and an `estimated`-tagged entry (`kur_biryani`) correctly rejected as an auto-correction source even with an otherwise-perfect high-confidence review. A third test covers the "no food_id to infer a portion from" case. All pass, alongside the full pre-existing suite (gating, safety rails, 5 failure modes, clarification path, confidence floor, alignment guard, targeted retrieval, and the complete Gemini/RPM/knowledge-layer regression battery).

**Not touched by this fix:** Gemini's RPM pacing, batching, retry/backoff, daily quota accounting, circuit breaker, Pacific-time reset, and every existing knowledge-layer function - re-verified, all still passing.

## Previous version: second-opinion reviewer (optional, off by default)

Adds `reviewer.py` - a completely separate, optional multimodal quality-control layer that double-checks Gemini's result before it reaches the user. **Off by default**: if `REVIEWER_API_KEY` isn't set, every function in `reviewer.py` is a no-op and the bot behaves exactly as it did before this feature existed - verified by importing the whole bot with the env var unset and confirming `reviewer.is_enabled()` is `False`.

**What it checks:** food identification (including known visual confusions like fried-vs-grilled chicken or beef-vs-lamb), hallucinated components, portion plausibility, calorie/macro plausibility, confidence calibration, Kurdish wording, and decision-rule compliance (e.g. should this have been a clarifying question instead of a confident number).

**Architecture - genuinely separate from Gemini, not just a second key:**
- Own API key (`REVIEWER_API_KEY`), own provider (`REVIEWER_BASE_URL`, default Groq), own model (`REVIEWER_MODEL`) - zero shared quota with `GEMINI_API_KEY`. Swapping provider (Mistral, OpenRouter, anything else exposing an OpenAI-compatible `/chat/completions` endpoint) is a config change, not a code change.
- Called from `bot.py`, not from inside `gemini_queue.py`'s worker loop - a reviewer-provider outage or rate limit can never touch Gemini's pacing, circuit breaker, or daily-quota accounting, and vice versa.
- Uses stdlib `urllib` for its HTTP call, not a new pip dependency - `requirements.txt` is unchanged by this feature.

**Gated, not run on every photo** (`reviewer.should_review()`): always reviews low/medium-confidence results; for a high-confidence result, only reviews if a food is unmatched to the glossary, matches a medium/high-severity `recognition_rules.json` confusion pair, the total exceeds `REVIEWER_KCAL_THRESHOLD` (default 1200), or there are `REVIEWER_ITEM_COUNT_THRESHOLD`+ items (default 4) - targets exactly the large-portion-overconfidence and over-decomposed-meal failure cases, while leaving the common simple case at zero added latency.

**Knowledge-layer context is retrieved, not dumped:** `knowledge.get_food_context_for_review()` and `knowledge.get_relevant_recognition_context()` pull only the database entries and confusion pairs/hints/brands relevant to the specific foods Gemini already identified - typically a few hundred to ~2,500 characters, not the full 144 KB file. This is a fundamentally easier problem than it was for Gemini's own prompt (see `data/prompt_fragments.md`'s header comment on why Gemini's call can't do this): the reviewer runs *after* identification, so it already knows which food_id(s) to look up.

**Corrections are conservative by construction, not by convention:** the reviewer can only replace a food's numbers by naming a real `food_id` from the knowledge layer (its own guessed numbers are never trusted directly), and only when it also reports high confidence in its own review. Anything short of that bar - an ungrounded guess, medium/low reviewer-confidence, a made-up ID - is treated as a disagreement signal (confidence gets capped down, or the result gets flagged for clarification) rather than an applied correction. Verified with dedicated tests: a made-up `corrected_food_id` is rejected and the numbers stay untouched; a valid ID at only medium reviewer-confidence is also rejected. The reviewer can never add a food item Gemini didn't report.

**Fails safe, unconditionally:** any error - timeout, HTTP error, malformed JSON, an unexpected exception - returns `None` from `reviewer.review_result()`, and `None` is handled identically to "gated out": Gemini's original result reaches the user completely unmodified. Tested against five separate failure modes (HTTP 429, timeout, malformed JSON content, unexpected response shape, a generic exception) - all five degrade to `None` without raising.

**Files changed/added this round:**
- `reviewer.py` (new) - the module itself.
- `knowledge.py` (extended, not modified) - three new functions (`get_food_context_for_review`, `get_relevant_recognition_context`, `build_reviewer_instructions`); nothing existing was changed.
- `data/reviewer_instructions.md` (new) - fixed, condensed reviewer-role instructions, same philosophy as `data/prompt_fragments.md` but for the review role specifically, not Gemini's initial recognition call.
- `vision.py` (one line added) - `_finalize_result` now persists the `food_id` it already computes during glossary matching instead of discarding it; this was previously computed and thrown away, needed so the reviewer can do targeted retrieval without redoing the fuzzy-match itself. No existing behavior changed.
- `bot.py` (two small edits) - one import line, and the reviewer call inserted between "Gemini result received" and "format + send to user," inside the existing `if result["status"] == "ok":` block.
- `.env.example` (documented, not required) - new optional `REVIEWER_*` variables, all commented out by default.

**Nothing else changed.** RPM pacing, per-model floors, windowed batching, 429-specific retry/backoff, daily quota accounting, Pacific-time reset, the circuit breaker, and every existing knowledge-layer function Gemini's own call relies on are untouched - re-verified with the full existing regression suite from prior rounds, all passing, plus the Pepsi/Pepsi-Zero-specific regression test.

## Previous version: knowledge-layer integration (plug-and-play)

Wires up the reviewed knowledge-layer files (`foods_database.json`, `recognition_rules.json`, `kurdish_style.md`, `decision_rules.md`) so the bot actually uses them, replacing `kurdish_foods.py`'s ~30-entry glossary with the full 127-entry multi-cuisine database and the documented recognition rules. See `knowledge.py` for the loader and `data/prompt_fragments.md` for what got pulled from the two `.md` docs (a curated excerpt, not the full text — see that file's header comment for why).

**Folder structure:**
```
data/                     - machine-loaded at runtime, read by knowledge.py
  foods_database.json     - the food knowledge base (127 entries)
  recognition_rules.json  - confusion pairs, brand mappings, visual hints
  prompt_fragments.md     - condensed excerpt of docs/ actually sent to Gemini
docs/                      - human-facing reference docs, NOT read by the bot
  kurdish_style.md        - full writing-style guide, for reviewers/maintainers
  decision_rules.md       - full decision framework, for reviewers/maintainers
knowledge.py               - loads data/, exposes prompt builders + fuzzy matcher
kurdish_foods.py           - DEPRECATED, no longer imported anywhere, kept for history
```

**Why `data/` vs `docs/` is a real distinction, not just tidiness:** the JSON files and `prompt_fragments.md` are read by `knowledge.py` every time the bot starts and shape what Gemini actually sees. `kurdish_style.md`/`decision_rules.md` are long-form documents written for a human reviewer (rationale, tables, checklists) — dumping them verbatim into every Gemini call would waste tokens on content the model doesn't need, much of which the hand-tuned system prompt in `vision.py` already covers (confidence rules, alternatives handling, language rules, insight style were already there before this round). `prompt_fragments.md` is a short, deliberately-curated excerpt of ONLY the genuinely new guidance from those two docs (the never-moralize rule, count-vs-estimate-area for discrete items, composite-dish handling, emoji restraint, unmatched-food category-level reasoning) — maintained by hand alongside the source docs, not auto-generated. If `docs/kurdish_style.md` or `docs/decision_rules.md` change, check whether `data/prompt_fragments.md` needs a matching update.

**How each file is loaded/used:**
- `foods_database.json` → `knowledge.build_glossary_prompt()` builds the same kind of reference-list block the old glossary did (name, emoji, aliases, per-serving macros), now covering all 12 cuisine/category groups instead of just Kurdish dishes. `knowledge.find_glossary_match()` fuzzy-matches whatever name Gemini returns against every entry's Kurdish/Latin/English/Arabic names, aliases, and misspellings, and relabels the result with the canonical name/emoji for consistency — same role the old `kurdish_foods.find_glossary_match()` played, same call site in `vision.py`, no changes needed there.
- `recognition_rules.json` → `knowledge.build_confusable_prompt()` turns confusion pairs, standalone visual hints, and brand mappings into a recognition-hints block injected into the same prompt slot the old `build_confusable_prompt()` used.
- `prompt_fragments.md` → `knowledge.build_decision_and_style_prompt()` returns it as-is, injected right after the confusable-prompt block.
- `kurdish_style.md` / `decision_rules.md` → not read by the bot at all. They're the source-of-truth documentation `prompt_fragments.md` was distilled from, and the reference for reviewing/extending it later.

**A real bug found and fixed during integration testing, not just wiring:** the original `find_glossary_match`'s substring-matching returned the FIRST alias found in list order, not the most specific one — meaning a query like `"pepsi zero"` could match plain `"drink_pepsi_regular"` (150 kcal/can) instead of `"drink_pepsi_zero"` (~1 kcal/can) purely because of dictionary ordering, not because of anything in the photo. This is exactly the class of error `recognition_rules.json`'s confusion pairs exist to prevent — except this instance was a matching-code bug, not a vision-model mistake. Fixed by checking for an exact term match first, then preferring the longest (most specific) substring match instead of the first one encountered. Verified with a test covering this exact case plus several adjacent ones (`pepsi`, `coke zero`, `coca cola`) to confirm no regressions.

**Startup resilience:** if `data/foods_database.json` or `data/recognition_rules.json` is missing or fails to parse, `knowledge.py` logs a clear error and continues with an empty glossary/ruleset rather than crashing the bot — Gemini falls back to its own judgment with no local reference data (a real quality degradation, but not an outage). Verified by testing with the file deleted and with a corrupted file separately.

**What was NOT changed:** the glossary match still only relabels a food's `name_kurdish`/`emoji` on match — it does not override Gemini's photo-scaled `kcal`/macros with the database's reference numbers, matching the original design's behavior (the prompt anchors Gemini's own estimate to the glossary reference values; post-hoc matching only fixes label consistency). Changing this to a hard override is a nutrition-accuracy tradeoff worth a deliberate follow-up decision, not something to fold into a pure integration pass.

## Previous version: RPM optimization (no redesign - same architecture, three targeted fixes)

Per your instruction: production data shows RPD (daily quota) is no longer the constraint - most failures are now RPM 429s, with plenty of daily headroom left. This round left the per-model-queue/proactive-daily-budget architecture untouched and fixed three concrete RPM bottlenecks found by tracing the actual pacing, batching, and retry code paths. All three were verified with real test runs (mocked Gemini calls, real asyncio timing) - see the "what was tested" note under each.

**1. [Primary bottleneck] The pacing floor could relax past the real RPM ceiling, and was shared identically across every model regardless of its actual limit.** `MIN_INTERVAL` was a single global `5.0s` (a 12 req/min ceiling) - but this project's own earlier notes (see the "Long-term scalability review" section below) put the real conservative ceiling at ~7-9 req/min. The adaptive layer's "ease down after 6 clean successes" logic was designed to walk the interval *down to that floor* over time, meaning a sustained-healthy period would predictably end in a 429 once pacing crept faster than the real ceiling - not bad luck, a designed-in outcome. The same shared floor also meant a materially faster model in the pool (e.g. Flash-Lite, typically a higher RPM ceiling than Flash) was needlessly held to Flash's conservative pace.

   **Fix:** `GEMINI_MODEL_POOL` now accepts an optional third field per model - `model:daily_budget:rpm_limit` - and `gemini_queue.py` derives that model's own pacing floor/base from it (`vision.MODEL_RPM_LIMIT`, `gemini_queue._min_interval_for_model`). Old two-field syntax (`model:budget`) still works unchanged, falling back to a conservative `DEFAULT_RPM_LIMIT=8`. **Verify your actual current per-model RPM limits** at https://ai.google.dev/gemini-api/docs/rate-limits (these move over time and vary by source) and set them explicitly, e.g. `GEMINI_MODEL_POOL=gemini-2.5-flash:225:9,gemini-2.5-flash-lite:900:14`. Tested: confirmed the derived floor differs correctly per model (~7.0s for a 9-RPM model vs ~4.5s for a 14-RPM model) and that the old two-field format still parses.

**2. [Batching efficiency] The batching window was effectively zero, which is why production batching rate stayed low.** The old drain only grabbed jobs that happened to *already* be sitting in the queue at the exact instant the worker picked up job #1 - in practice, almost never, since real submissions from different users/moments land milliseconds to seconds apart, not within the same event-loop tick. Meanwhile the worker was about to sit idle for a full pacing wait (5-30s) anyway before the next request could legally go out - dead time that was being wasted instead of used to catch batch-mates.

   **Fix:** the worker now keeps listening for new arrivals for the *remainder of that same mandatory pacing wait* (`gemini_queue._extend_batch_during_wait`), instead of sleeping through it. This is zero added latency by construction - the wait was happening regardless, batched or not; the only thing that changed is what the worker does while waiting. Tested: simulated a realistic 4-photo burst arriving over 300ms - the old instant-only drain produced 3 real Gemini requests for those 4 photos, the new listening-window logic produced 2. A heavier 7-photo burst correctly capped batches at `BATCH_SIZE=5` and still completed all 7 jobs across the minimum number of requests (3).

**3. [Wasted retries] 429 retries were using a backoff schedule tuned for transient 5xx errors, not RPM windows, so rate-limited jobs almost always burned all 4 retry attempts for nothing.** `BASE_BACKOFF_SECONDS=2.0` with 2s/4s/8s exponential steps is reasonable for a transient 503 (which really can clear in seconds) but Gemini's RPM limit is a ~60-second rolling window - retrying after 2-4-8s is retrying against a window that has almost certainly not moved. In production this meant a rate-limited job typically made 4 real HTTP attempts, 3 of them doomed from the start, before finally giving up - wasted round-trips, plus a delay before the queue's reactive AIMD/circuit-breaker layer got to react (it only sees the final outcome of the whole job).

   **Fix:** 429s now get their own short retry budget (`MAX_RATE_LIMIT_ATTEMPTS=2`, i.e. one real retry) with a meaningfully longer, RPM-window-appropriate backoff floor (`RATE_LIMIT_BACKOFF_SECONDS=15.0`, or the server's suggested wait if longer, capped the same as everything else). Transient 5xx/JSON-parse retries are completely untouched - still the fast original 2s/4s/8s schedule, still up to `MAX_ATTEMPTS=4` attempts. Tested: sustained 429s now stop after 2 real attempts instead of 4; a 429-then-recovers case still succeeds correctly; a sustained-503 case confirmed unchanged behavior (still 2s/4s/8s, still 4 attempts).

**Explicitly not touched this round, and why:** food recognition accuracy, nutrition data, Kurdish language content (per your instruction - out of scope). Multiple API keys/projects (quota circumvention, not architecture - consistent with prior rounds' rejection of this). The daily-budget/proactive-routing architecture itself, the circuit breaker's trip threshold/cooldown curve, and the cache/dedup layer - none of these were implicated by the evidence; changing them without a proven bottleneck would just be guessing.

### Expected effect on production metrics

- **RPM 429s: down.** The two biggest drivers - a pacing floor that could legitimately exceed the real ceiling, and 429 retries hammering an already-exceeded window with a too-fast backoff - are both fixed. Some 429s will still happen (this is still free-tier, still a hard ceiling, still no per-model live signal from Google) but they should no longer be a *designed-in* consequence of normal healthy operation.
- **Successful requests during bursts: up.** Fewer wasted retry round-trips per rate-limited job, plus a real (not near-zero-width) batching window that specifically activates during the exact bursty conditions where 429s are most likely - this directly targets "increase successful requests during bursts."
- **Circuit breaker activations: down.** The breaker trips on 3 *consecutive rate-limited jobs*. With a correctly-floored pacer producing far fewer 429s in the first place, and 429'd jobs failing in ~15-20s instead of ~14s+ of doomed retries (so the reactive layer reacts sooner per job), the conditions that build up 3 consecutive rate-limited jobs should occur less often.
- **Batching rate: measurably up from the reported low baseline.** Confirmed directly in testing (3→2 requests for the same 4-photo burst; see above) - this was previously near-zero specifically because the old drain had no time window at all, not because bursts don't happen.
- **Average response time: roughly unchanged for the single-photo case** (the windowed listening only ever consumes time that was going to be spent waiting anyway), **and improved for jobs caught in a burst** (they now often ride an existing batched request instead of queuing for their own full pacing slot). The only case with *added* latency is a rate-limited job's own worst case, which changes from ~14s across 4 doomed attempts to ~15-20s across 2 attempts - comparable wall-clock time, half the wasted requests, and a better chance the retry actually lands.

**Rejected this round:** a fixed artificial batching delay (e.g. "wait 1.5s for more photos to arrive") - would add real latency to the common single-photo case for no reason, when the existing mandatory pacing wait already provides that time for free. Retuning `INTERVAL_INCREASE_FACTOR`/`CIRCUIT_BREAKER_THRESHOLD` - no evidence these specific curves are miscalibrated once the floor itself is corrected; would be guessing without data.

## Previous version: quota-system audit (iterative fixes, no redesign)

Per your instruction, this round only touches the existing quota architecture - no new components, no redesign. Also fixes a real crash bug from the previous handoff (`DEFAULT_DAILY_BUDGET` used in `gemini_queue.py` without being imported - `NameError` on the very first budget calculation). Findings below, prioritized by estimated impact, all tested.

**1. [Highest impact] Daily counter was tracking jobs, not real HTTP attempts.** `estimate_calories()` can retry internally up to 4 times on transient errors - each retry is a real Gemini request. The daily counter only incremented once per *job*, regardless of how many real attempts it took. This directly explains the reported symptom: tracker showed 2/200 used while 3 real 429s occurred - the true request count was higher than the tracker knew. Fixed by having `estimate_calories`/`estimate_calories_batch` report `billable_attempts`, and the worker now increments the daily counter by that real count. Tested: a job with 2 real failures + 1 success now correctly counts as 3, not 1.

**2. [Moderate impact] 429s were being counted as "used" against the daily budget.** A 429 is typically rejected by Google's rate limiter *before* processing - it's not usually billed against your quota. Counting it as "used" locally made the tracker artificially more pessimistic than the real account state, encouraging earlier self-limiting than necessary. Fixed: `billable_attempts` excludes 429s specifically (a 503 or other real processed failure still counts - only pre-processing rejections don't). Tested independently of finding #1.

**3. [Low-moderate impact, zero risk] Daily reset was aligned to UTC midnight, not Google's actual Pacific Time reset.** This created a misalignment window of up to 8 hours (depending on PST/PDT) where the local tracker could show "new day, full budget" while the real account was still mid-cycle (false abundance - could contribute to real 429s), or the reverse (false scarcity - needlessly self-limiting for hours after Google already reset). Fixed with DST-aware `America/Los_Angeles` as the default reset boundary, configurable via `GEMINI_QUOTA_RESET_TIMEZONE` if ever wrong for your project. Added `tzdata` to `requirements.txt` since minimal Docker images (Railway's included) sometimes lack the system timezone database that `zoneinfo` needs - without it this would silently fall back to UTC.

**4. [Low impact, zero risk, zero latency] Cache TTL extended 1hr → 24hr, capacity 500 → 1500 entries.** A cached analysis of a specific photo never goes stale - it's still the same food. A longer window only ever helps catch repeat-day patterns (same breakfast photo reused across days), never hurts, costs nothing.

**5. [Very low impact, zero risk, zero latency] Batch size cap 3 → 5.** Purely opportunistic - only changes how much of a rare real backlog gets folded into one request when one happens to form. Never adds latency to the common case.

**Rejected that round:** retuning `BASE_INTERVAL`/`MIN_INTERVAL` preemptively without evidence. This round found that evidence (see above) and made the change.


## Previous version: quota architecture redesign

Real production data (cache ~3-4%, batching rare) confirmed request-level efficiency isn't the lever that matters - duplicate/concurrent submissions are genuinely uncommon for this bot. This round redesigns the actual bottleneck: **daily quota management**.

**The core problem with the old design:** it was reactive. A model was only known to be exhausted after real 429s started coming back - each costing a wasted request and up to ~90s of retry time. And failover only kicked in after the preferred model's circuit broke, so for most of the day one model's quota sat unused while the other absorbed all the traffic.

**What changed:**

1. **Per-model dedicated queues and workers.** Each model in the pool now gets its own queue and its own worker task, running truly concurrently - a Flash-Lite request no longer waits behind a Flash request for no reason. Tested: two jobs on different models complete in the time of ONE slow call, not two.
2. **Proactive daily budget tracking.** Configure `GEMINI_MODEL_POOL=gemini-2.5-flash:225,gemini-2.5-flash-lite:900` (model:daily_budget pairs) and the system counts requests locally, stopping *before* a model's daily quota is spent instead of finding out via a wave of failed requests. Tested: budget correctly decrements, floors at zero, and an exhausted model is proactively excluded from routing.
3. **Budget-paced throttling** - the actual fix for "dead by 2pm." Each model self-paces to spread its *remaining* budget across the *remaining* hours of the day (`seconds_left_in_day / budget_left`). Tested: front-loading 80% of a budget correctly forces 5x harder throttling on the rest, rather than just running out.
4. **Pool-wide smart routing.** Every submission goes to whichever healthy model has the most *proportional* daily headroom - this naturally load-balances across the whole pool over the day instead of draining one model first.
5. **Reactive circuit breaker kept as the safety net** for when the configured daily budget turns out to be too generous (Google changes these without notice) - tested independently, still trips correctly on real sustained 429s regardless of what the local budget counter thinks.
6. **`/stats` now shows daily budget usage per model** (used/budget/remaining), not just pacing state - this is the metric that actually answers "how close are we to running out today."

**Explicitly rejected: multiple API keys/projects to multiply free quota.** This is quota circumvention against the provider's terms, not architecture - not doing it, consistent with the "no fake bypasses" instruction.

**Fully backward compatible:** if `GEMINI_MODEL_POOL` isn't set, the system falls back to single-model mode using `GEMINI_MODEL` with a generous default daily budget - existing deployments keep working unchanged. Verified with a dedicated backward-compat test.

**Deployment - one new env var, everything else unchanged:**
```
GEMINI_MODEL_POOL=gemini-2.5-flash:225,gemini-2.5-flash-lite:900
```
Leave unset to keep single-model behavior. Budgets above are conservative estimates (~90% of last-known free-tier limits) - verify your actual current limits at https://ai.google.dev/gemini-api/docs/rate-limits and adjust, since Google has changed these before without notice.

**Previous round's A/B testing (`AB_TEST_MODEL`/`AB_TEST_PERCENTAGE`) has been removed** in favor of the model pool, which does capacity-aware routing better than a fixed percentage split. `model_used` tracking on every meal is kept, so `/stats`' per-model comparison still works using the pool's natural traffic split as organic comparison data.

## Previous version: real A/B testing infrastructure, and an honest read on the production data

**What your data actually tells us:** 0% cache hits and ~0% batching opportunities over several real days means people genuinely don't send duplicate or near-simultaneous photos - not that thresholds are wrong. No further tuning of either system will help; that's not a bug to fix, it's a property of how this bot gets used. I'm not touching either system further based on this.

**Database expansion doesn't reduce Gemini calls.** Worth being explicit: a bigger `kurdish_foods.py` improves the *accuracy* of results Gemini already returns - it does not change whether Gemini gets called. These are separate levers. Quota reduction has to come from somewhere else.

**What I built instead - real Flash vs Flash-Lite A/B testing:**
- `AB_TEST_MODEL` and `AB_TEST_PERCENTAGE` env vars. Set `AB_TEST_MODEL=gemini-2.5-flash-lite` and `AB_TEST_PERCENTAGE=20` (or whatever split you want) and 20% of *users* (not random requests - deterministic per-user via a hash split, so the same user always gets the same model, keeping the comparison uncontaminated) start using Flash-Lite immediately, no deploy needed to change the split.
- Every meal now records which model produced it. `/stats` shows a live comparison: meal count, high-confidence rate, and correction rate, per model.
- I can't call the live Gemini API from this sandbox to benchmark this myself - this is the honest alternative: real production data, automatically collected, instead of a guess.
- Batching correctly respects the split - a batch can only combine jobs assigned the same model (mixing models in one request doesn't make sense); non-matching jobs get safely requeued rather than dropped. Given batching is already ~0% in practice, this is correctness-for-later rather than something you'll see today.

**Recommendation once you have a few hundred meals split across both:** if Flash-Lite's high-confidence rate and correction rate land within a few points of Flash's, switch `GEMINI_MODEL` to it and drop the A/B test - the free-quota difference (~4x) is too large to leave on the table for a marginal accuracy gap.

## Previous version: race condition fix + diagnostics + prompt improvements

**Real bug found and fixed:** the daily-limit check read the count of already-*logged* meals, but a meal only logs after the full Gemini round-trip (several seconds). With `concurrent_updates=True`, multiple rapid photos from the same user ran as concurrent handlers and could all pass the check before any of them wrote back - exactly matching your report of 6 requests through a 5-limit. Fixed with an atomic reserve/release pair (`storage.reserve_daily_slot`/`release_daily_slot`) - the check-and-increment now happens in one synchronous call with no `await` inside it, which asyncio guarantees can't be interleaved. Proved this two ways: reproduced the old buggy behavior standalone (6/6 succeeded), then confirmed the fix (exactly 5/6 succeed, matching the limit).

**Stats gaps closed:** `cooldown_rejections` was defined but never actually incremented anywhere - fixed. Added `daily_limit_blocks` and a true `total_photos_received` counter, so `/stats` can now distinguish total requests, real Gemini requests, and each block reason separately, as asked.

**Batching diagnostics:** added average/max queue-depth tracking and a `batching_opportunities` counter, visible directly in `/stats` - no more log-grepping needed to answer "was batching even possible." Rejected the artificial collection-window idea again on the same grounds as last time: it would add latency to every solo request to occasionally catch a batch, and there's still no data suggesting that trade is worth it.

**Prompt improvements:** added an explicit verification step ("could you point to the exact pixels of this food? if not, remove it") directly targeting the phantom-bread false positive; added brand-name preservation (keeps "Ülker Biskrem" instead of a generic description when packaging is legible); strengthened the natural-Kurdish-naming instruction to prefer authentic local dish names over generic translations.

**Real gap found in review (item 11):** the Gemini client had no request timeout configured - a hung call (rare, but possible) would have blocked the single worker, and therefore every queued user, forever with no recovery path. Added a 45s client-side timeout.

**Deferred again, unchanged reasoning:** food database expansion, nutrition-value refinement, and the full analytics dashboard remain real asks but too large for this pass alongside a genuine concurrency bug fix.

## Quota-optimization architecture (previous version)

Reframed around one fact: Gemini's free-tier RPM is a permanent, fixed ceiling that no code change raises. So this round is entirely about minimizing real Gemini requests, ranked and implemented in order of actual impact - full reasoning and rejected alternatives below.

**1. Opportunistic batching (`vision.estimate_calories_batch`, `gemini_queue.BATCH_SIZE`) - the standout idea.** RPM limits count *requests*, not images-per-request. When multiple photos are already queued at the moment the worker picks up work, they're now analyzed in ONE Gemini request instead of N. Never adds artificial latency for the single-photo case - it only batches what's *already* waiting, never waits around hoping more arrives. Capped at 3 per batch deliberately: a batch's fate is shared (one failed request fails every job in it), so the cap bounds the downside. Tested: confirmed a single submission still uses the plain single-image path untouched, confirmed 3 concurrent submissions correctly collapse into 1 real Gemini call with each result routed back to the right requester (verified by unique per-image size), and confirmed a failed batch applies the same outcome to every job in it rather than silently losing track of any.

**2. Local pre-filter (`vision.check_image_locally`) - catches junk before it costs a request.** Deliberately narrow: only rejects images that are near-certain to fail anyway (near-blank or near-black frames, via pixel variance/brightness checks), never tries to judge "is this food" - that's Gemini's job, and a wrong local rejection of a valid photo is worse than one wasted request. Pure Pillow, no new dependency. Tested against a realistic textured "food-like" image (correctly passes) and both a blank and a near-black frame (correctly rejected).

**3. Conservative perceptual-hash (dHash) near-duplicate cache.** Hand-rolled 64-bit dHash using only Pillow - no new dependency. Deliberately scoped narrow: catches the real, specific scenario of someone resending essentially the same photo after lossy recompression (forwarding, screenshotting, WhatsApp re-saving), which breaks exact SHA-256 matching but not this. NOT used for loose "similar-looking food" matching - tested the same image at very different JPEG quality (Hamming distance ~1) against two genuinely different images (Hamming distance ~31), a 30-bit margin that lets the strict threshold (≤4) catch real duplicates with essentially zero false-positive risk. End-to-end tested through the actual queue: a recompressed duplicate correctly reuses the cached result with zero additional Gemini calls.

**4. Dynamic/escalating per-user cooldown.** Normal meal-logging (a few photos per day) never reaches the escalation thresholds. Rapid-fire submission patterns (5+ in 5 minutes) get progressively throttled, decaying back to normal automatically. Tested: confirmed a normal-paced usage pattern never escalates, confirmed a rapid-fire pattern correctly escalates starting at the configured threshold.

**5. Data-collection foundation for a possible future local-recognition layer (`analysis_fingerprints` table).** Every successful analysis now logs its dHash fingerprint and outcome. This is *purely* additive logging - nothing reads this table to skip a Gemini call yet. Deliberately deferred, not half-implemented: with zero accumulated data today, a bypass built on this would either rarely trigger (no real savings) or need a loose-enough threshold to get coverage, which risks silently serving wrong nutrition data. Revisit once this table has real volume (months, not days).

**6. Small UX copy nudge** - the welcome message now mentions sending multiple dishes on one plate as a single photo (a capability that already existed but wasn't advertised), reducing accidental redundant submissions. Free, one line, flagged for the usual native-speaker review.

**`/stats` now shows quota-specific savings**: exact-cache hits, near-duplicate (phash) hits, and requests saved via batching, separately from the reliability metrics added last round.

### Explicitly rejected, with reasoning
- **Full local ML classifier bypass (today)** - would be the highest-value idea eventually, but implementing it now means zero training data, real accuracy risk from forcing coverage, and a heavy-dependency footprint (PyTorch/TensorFlow) that risks blowing past Railway's free-tier resource limits. The safe move is building the data foundation now (#5) and revisiting the actual bypass once it has months of real volume.
- **Loose/aggressive perceptual hashing** ("similar-looking food" matching, not just near-identical photos) - real risk of two *different* dishes matching as "close enough" and silently serving wrong nutrition data. The strict, narrow version (#3) captures the legitimate use case without this risk.
- **"Food-result cache" as an independent lever** - doesn't actually reduce calls without a non-Gemini recognition method for *new* photos; it's not a separate technique from the image-hashing/local-CV ideas, just a different name for the same dependency.
- **Non-ML "food vs non-food" classifier** - classical CV can't reliably distinguish food from non-food by color/texture alone; a false rejection of a valid photo is a worse outcome than one wasted request. Only kept the much narrower, much safer "obviously blank/black" filter (#2).
- **True priority-queue reordering** (first-time users before repeat testers) - doesn't reduce the number of Gemini calls at all, only their order. Out of scope for a "minimize Gemini usage" goal specifically, even though it might have separate fairness value.
- **Prompt/token compression** - doesn't address request-count (RPM), which is the confirmed bottleneck; would only help if a separate token-based (TPM) limit turns out to be binding, which isn't established.

## Bug fix: circuit breaker feedback loop (previous version)


**What you saw:** `/stats` showing 27 rate-limit errors, circuit breaker permanently active, pacing pinned at the 30s ceiling, queue empty.

**Root cause, confirmed and reproduced with a test:** the circuit breaker's own synthetic "busy" responses (returned when the circuit is open, *without ever contacting Gemini*) were being fed back into the same statistics that decide whether to keep the circuit open. Every short-circuited request looked exactly like "another confirmed 429" to the tracking logic - so once the circuit tripped, it could re-justify staying open off its own defensive output, indefinitely, regardless of whether Gemini itself had recovered. The `rate_limited_failures` counter in `/stats` was also conflating real Gemini responses with synthetic short-circuits, so "27" didn't necessarily mean 27 real 429s.

**Fix:** only real Gemini attempts now feed the adaptive-pacing/circuit-breaker stats (`gemini_queue.py`, `_worker`). Short-circuited requests are counted separately (`circuit_breaker_short_circuits`, now shown distinctly in `/stats`) and never touch the real failure counters. Reproduced the exact bug (tripped the circuit with 3 real failures, then fed it 10 synthetic short-circuits) and confirmed the real counters correctly stay at 3, not climb to 13.

**Also added:** exponential circuit-reopen backoff (60s → 120s → 240s → capped at 300s) for genuinely sustained failures, resetting the moment a real recovery probe succeeds. A burst-style rate limit clears in one 60s window; a truly exhausted daily/project quota won't, and probing every 60s for hours serves no purpose. Tested: confirmed cooldowns grow 0.2→0.4→0.8→capped in a scaled-down simulation, and confirmed a successful real probe resets everything (interval, consecutive-failure counter, reopen backoff) back to healthy.

**On your actual "is this a real quota exhaustion" question:** with the bug fixed, if you deploy this and *still* see sustained real `rate_limited_failures` climbing (not `circuit_breaker_short_circuits`), that's now a trustworthy signal of genuine Gemini-side exhaustion, not a code artifact. At that point:
- Check https://aistudio.google.com/apikey confirms your key is still active and matches Railway's `GEMINI_API_KEY` env var exactly (a silently-regenerated or mismatched key typically shows as 401/403, not 429, but worth ruling out first).
- Check your actual current limits and usage at https://ai.google.dev/gemini-api/docs/rate-limits - Google has cut free-tier limits before without much notice, and there's a separate daily (RPD) cap in addition to the per-minute one; sustained 429s across many minutes (not just a burst) point to RPD, not RPM.
- If RPD is exhausted, the only real fix is waiting for the daily reset (or, if you're past validating the MVP, enabling billing on the same project - the code needs zero changes for that, per the earlier Gemini setup notes below).

## Long-term scalability review (previous version)


The core constraint that shapes everything below: Gemini's free-tier RPM (~7-9/min at our conservative pacing) is a hard ceiling no code change increases. So the real goal isn't "handle thousands of *simultaneous* analyses" — it's *never waste a request, degrade gracefully under backlog, and stay memory-safe while queued*. Everything here is filtered through that.

**Implemented (genuine, measured impact):**
- **Image optimization moved before the queue, not inside the worker.** A backlog used to mean megabytes of full-size phone photos sitting in memory per queued job. Now the queue only ever holds the ~30-50KB optimized version.
- **Adaptive pacing (AIMD)** replaces the fixed 7s guess. Backs off hard (×1.6) the instant a real 429 happens; cautiously eases down (−0.25s) after 6 consecutive clean successes, floor 5s / ceiling 30s. Tested: confirmed it speeds up under sustained health and snaps back on real rate-limit evidence.
- **Circuit breaker**: after 3 consecutive rate-limited failures, opens for 60s and every queued job gets an instant honest "busy" response instead of each one separately burning ~90s on a doomed retry cycle. Tested: confirmed zero Gemini calls happen while the circuit is open, and it recovers automatically after cooldown.
- **DB indexes** on `meals(user_id, created_at)` and a partial index on `feedback`. Verified with `EXPLAIN QUERY PLAN` that SQLite actually uses them, not just that they exist. Every `/today`/`/week`/`/history` query hits this.
- **Defensive worker loop**: an unexpected exception anywhere in a job (not just classified API errors) used to have a theoretical path to silently killing the entire background worker - permanent outage until a manual restart. Tested by injecting a raw `RuntimeError` mid-analysis and confirming the worker survives and keeps processing the next job.
- **Queue depth cap** (40): beyond this, new submissions fail fast with a "very busy" message instead of queuing into a wait time of tens of minutes.
- **`/stats` command**: real observability - total requests, cache hit rate, current adaptive interval, circuit breaker state, queue depth. Not gated by any admin check (this app has no auth concept); restrict it later by checking `update.effective_user.id` if you want.
- **Cache bumped 200 → 500 entries**, and stale per-user cooldown entries get swept periodically - both cheap, bound memory more tightly under long-term growth.

**Considered and explicitly rejected (explained, not just skipped):**
- **Perceptual/near-duplicate image hashing** - real risk (two different dishes falsely matching as "similar enough" would silently serve wrong nutrition data) against a low expected benefit (people rarely re-photograph the exact same plate for this kind of app). Not worth it.
- **Migrating off SQLite** - Gemini's RPM ceiling is 1-2 orders of magnitude below anything SQLite+WAL can handle; it will never be the actual bottleneck.
- **A persistent/durable job queue surviving restarts** - the real queue is rarely more than a handful of jobs deep given the RPM ceiling; not worth the engineering effort to protect a rare, low-cost event.
- **SQLite connection pooling** - per-call overhead (~1ms) is noise next to the multi-second Gemini pacing dominating the critical path.
- **Downscaling images below 1024px** - would save a little more bandwidth at real risk to recognition accuracy.
- **Redis or an external queue/cache service** - reintroduces a paid dependency for no benefit at this scale.

## Scalability & reliability update (previous version)

**Root issue diagnosed:** Google cut Gemini's free-tier rate limits significantly in recent months - some tiers are down to single-digit requests per minute. The bot's own logic was healthy; nothing was calling Gemini more than once per photo. The 429s were real quota pressure, not a bug in the analysis code.

**What changed, and why each piece matters:**

1. **Verified single-request-per-photo** — confirmed by code inspection and an automated test: exactly one call site (`gemini_queue.submit_photo_job`) is reachable from `handle_photo`, and `estimate_calories`'s internal retry loop only fires on an actual failure, never duplicates a successful call.
2. **`gemini_queue.py` (new file)** — a single background worker processes all photos sequentially with an enforced minimum gap between real Gemini calls (`MIN_SECONDS_BETWEEN_REQUESTS`, default 7s ≈ 8-9 req/min). This is the actual fix for burst 429s: no matter how many users upload at once, requests leave at a safe, steady pace instead of firing all at once. **This is the single most important tunable in the whole update** — if you still see `[RATE_LIMIT]` in your Railway logs after deploying, raise this number. Check your current real limit at https://ai.google.dev/gemini-api/docs/rate-limits, since Google has changed it before without much notice.
3. **Retry logic in `vision.py`** — the google-genai SDK's own built-in retry is disabled (it has a known bug where it ignores the server's suggested retry delay). Our own loop retries up to 4 times on 429/500/502/503/504/timeouts with exponential backoff, and parses the server's suggested wait time out of the error message when present. Non-retryable errors (400/403/404 — bad key, bad request) fail immediately instead of wasting attempts.
4. **Two different failure messages** — a rate-limit exhaustion now shows the Kurdish "بۆتەکە زۆر بەکاردەهێنرێت" message instead of the generic "check your photo" tips, since the two situations need different user reactions.
5. **Per-user cooldown** (`gemini_queue.check_user_cooldown`, default 8s) — checked *before* a photo even enters the queue, so one user spamming photos can't consume quota that other users are waiting on.
6. **Duplicate-image cache** — every photo is hashed (SHA-256); an identical photo analyzed within the last hour returns the cached result instantly with zero Gemini calls. Useful for accidental double-sends and repeat photos.
7. **Image optimization** (`vision.optimize_image`, needs the new `Pillow` dependency) — resizes to 1024px on the long side at JPEG quality 85 before upload. Tested against a realistic phone-photo-sized image: meaningfully smaller upload with no loss to recognition quality, since 1024px is well above what's needed to identify food and read portions.
8. **Structured logging** — every failure path now logs a clear tag: `[RATE_LIMIT]`, `[SERVER_ERROR]`, `[TIMEOUT]`, `[JSON_PARSE]`, `[SDK_ERROR]`, `[UNEXPECTED]`, `[QUEUE]`, `[CACHE]`, `[IMAGE_OPTIMIZE]`. Searching Railway logs for any of these tags should make debugging take minutes, not hours.
9. **Failed requests were already never saved** — verified this was already correct (only the `status == "ok"` branch calls `storage.log_meal`), and added an automated test to lock in that guarantee going forward.
10. **Additional free optimizations found in review:**
    - **The blocking Gemini call now runs via `asyncio.to_thread`** inside the queue worker — this was a real (if invisible) bug before: `client.models.generate_content()` is a synchronous/blocking call, and calling it directly inside an `async def` handler froze the *entire bot* (all users, all commands) for the duration of every single photo analysis. This was arguably a bigger scalability problem than the 429s themselves.
    - **SQLite WAL mode** enabled (`storage.py`) — lets reads and writes happen concurrently instead of blocking each other under multiple simultaneous users. One line, no downside.
    - **Corrections prompt already capped at 60 entries** (pre-existing) — confirmed this stays bounded as your correction count grows, so prompt size/token cost doesn't creep up unbounded over time.

**What I deliberately did NOT change:** recognition prompt logic, glossary, macro calculations, or anything user-facing about the analysis itself — this update is purely about *reliability of delivery*, not accuracy.

## What this bot does now
1. **Photo analysis**: send a meal photo, Gemini identifies every distinct food (including drinks, sauces, oils, bread, sides, garnishes), estimates portions using visible reference objects (plate/bowl/spoon/hand), and calculates calories + macros per item and as a total.
2. **Genuine uncertainty handling**: for visually confusable foods (e.g. pomegranate molasses vs tomato sauce), the bot gives its best estimate plus 1-2 alternative readings instead of silently guessing — but only when there's real ambiguity, not by default.
3. **Personalized targets**: `/profile` walks through a short setup (age, sex, height, weight, goal, activity level) via buttons/short text answers, then calculates BMR, TDEE, and daily calorie/protein/carb/fat targets (Mifflin-St Jeor equation — the standard free formula, no paid nutrition API needed).
4. **Daily tracking**: every meal is logged; `/today`, `/week`, `/month` show totals, and `/today` shows progress against your personal targets once set up.
5. **Meal quality feedback**: after each meal, a rule-based (not AI, so it's instant and free) read on whether it's high-protein, high-carb, high-fat, balanced, and whether it fits your current goal.
6. **User corrections that actually help**: tap ✏️ on any result to correct it in your own words. That correction is saved and automatically included as extra context on every future photo analysis for every user — a real free "learning" loop, no model retraining, no external service.
7. **Full command set**: `/start /help /profile /goal /today /history /week /month /reset /settings`, with inline buttons wherever they save typing.

## Review: weaknesses in the previous version (what this update addresses)
- **Glossary was too narrow** (31 dishes, no drinks/desserts/fruits/vegetables/sauces/oils) — now 64+ entries across all those categories.
- **No mechanism to distinguish visually similar foods** — added an explicit confusable-pairs list (starting with pomegranate molasses vs tomato sauce) that teaches the model what to actually look for, plus the alternatives system for genuine ambiguity.
- **No portion-estimation anchor** — the model had no instruction to use plates/hands/spoons as scale references; now it does.
- **All estimates were single-shot with no user memory** — corrections vanished after each message. Now they're persisted and reused.
- **No personalization** — same targets-free experience for every user regardless of goals. Now there's a full profile + daily targets system.
- **No qualitative meal feedback** — users got numbers with no interpretation of whether the meal fit their goals.
- **Everything free-text driven** — every interaction required typing. Now buttons handle sex/goal/activity/confirmation choices.

## Known limitations (honest, not glossed over)
- **Portion accuracy from a single 2D photo has a hard ceiling.** No free vision API can truly measure volume from one angle — reference-object anchoring helps a lot but this will never be lab-accurate. This is a property of photo-based estimation in general, not something more prompting fully solves.
- **The correction system is prompt-based, not real training.** It works well at moderate scale (tens to low hundreds of corrections fit comfortably in the prompt), but isn't a substitute for a real fine-tuned model if you eventually have thousands of corrections — the fix at that point would be pruning to the most valuable ones, not a code change.
- **Free Gemini tier rate limits still apply** (see below) — unchanged from before, just worth repeating since usage will grow with more features.

## Deployment (mostly unchanged from before)
Same two keys as before — nothing new to set up:

1. **Telegram**: @BotFather → `/newbot` → copy the token.
2. **Gemini**: https://aistudio.google.com/apikey → sign in → "Create API key". Still genuinely free, no card, no expiration.
3. Fill in `.env` (rename from `.env.example`), same two variables: `TELEGRAM_BOT_TOKEN`, `GEMINI_API_KEY`.
4. Deploy on Railway/Render the same way as before: push this folder, set the two env vars, start command `python bot.py`.
5. **This is safe to deploy directly over your already-running bot.** The database migration (new `users` and `corrections` tables, new columns) runs automatically on startup and never touches or drops existing data — verified with a migration test against a simulated copy of the old schema before shipping this.

## New files in this version
- `nutrition.py` — BMR/TDEE/target math (Mifflin-St Jeor) and rule-based meal quality analysis. Pure calculation, no AI call, instant and free.
- `gemini_queue.py` — request pacing, per-user cooldown, and duplicate-image caching (see the scalability section above).
- **One new dependency**: `Pillow` (image resizing) — still fully free/open-source, added to `requirements.txt`. Redeploying on Railway will pick it up automatically.

## Improving the glossary and confusable pairs
Same as before — `kurdish_foods.py` is still a plain list, copy-paste to add a dish. Two things are new in this file:
- `CONFUSABLE_PAIRS` — add more pairs here as you discover them (format matches the pomegranate-molasses example already in the file).
- `find_glossary_match()` — fuzzy matching, no need to touch this unless you want to tune the similarity cutoff.

Run `python review_feedback.py` anytime to see both 👎 flagged results AND all corrections learned so far in one place.

⚠️ **Still true, still important**: I'm not a native Kurdish speaker. I've written every string (including 30+ new ones for profile setup, meal analysis, and the new commands) in what I believe is natural, everyday Sorian — but please read through `bot.py`, `vision.py`'s prompt, and `nutrition.py`'s Kurdish labels before wider launch.

## What's intentionally not built (would break the "100% free" or "keep it simple" constraints)
- Full ConversationHandler-based multi-step flows — used a simpler DB-backed step tracker instead, which is more restart-safe anyway.
- Any external nutrition database API — all values are hand-curated in `kurdish_foods.py`, which is actually more reliable for Kurdish dishes specifically than a generic (and often paid) nutrition API would be.
- Photo-based learning (e.g. storing corrected images for a vision model) — would require real training infrastructure, which isn't free. The text-based correction loop is the practical free alternative, with the limitation noted above.

## 128 MB server secrets

This build does not use `python-dotenv` or the Google GenAI SDK. To keep memory usage low, it reads secrets from `bot_secrets.env` using Python's standard library.

1. Open `bot_secrets.env` in the server Files tab.
2. Replace the two placeholder values:
   - `TELEGRAM_BOT_TOKEN=...` with the token from BotFather.
   - `GEMINI_API_KEY=...` with your Gemini API key.
3. Save the file.
4. Start the server.

Keep `bot_secrets.env` private and never commit it to GitHub.
